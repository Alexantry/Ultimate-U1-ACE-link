"""Installer transaction tests use only temporary files and virtual services."""
import copy
import contextlib
import importlib.util
import io
import itertools
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

SPEC = importlib.util.spec_from_file_location('u1_installer', Path(__file__).resolve().parents[1] / 'installer.py')
I = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(I)

ACE = ('class BunnyAce:\n' + ''.join('    %s = %s\n' % (name, value)
                                    for name, value in I.CONSTANTS.values())).encode()


class FakeHost(I.Host):
    def __init__(self, root):
        super().__init__(root, self.snapshot, self.service_action)
        self.actions = []; self.active = False; self.ready_failure = False
        self.snapshot_override = None; self.fail_write = None
        self.rfid_actions = []; self.openrfid_running = False
        self.candidates = [I.DEFAULTS['serial']]
        self.initial = {
            'webhooks': {'state': 'ready'}, 'print_stats': {'state': 'standby'},
            'idle_timeout': {'state': 'Idle'},
            'machine_state_manager': {'main_state': 0, 'action_code': 0},
            'print_task_config': {'filament_vendor_0': 'Bambu', 'filament_type_0': 'PLA Matte'},
            'configfile': {'settings': {}}, '_config_file': I.CONFIG_ROOT + '/printer.cfg'}
        for name in ('extruder', 'extruder1', 'extruder2', 'extruder3', 'heater_bed'):
            self.initial[name] = {'target': 0, 'power': 0, 'temperature': 25}
        for i in range(4):
            self.initial['filament_motion_sensor e%d_filament' % i] = {'filament_detected': False}

    def persistence(self):
        # Real bind mounts cannot be created in a cross-platform unit test.
        I.require(self.path('/oem/.printer_data').is_file(), 'Missing test persistence marker')

    def serial_candidates(self):
        return self.candidates[:]

    def rfid_files(self):
        I.require(self.read(I.RFID_TWEAK) == b'[fm175xx_reader]\nenabled: False\n',
                  'Invalid test RFID tweak')

    def rfid_running(self):
        return self.openrfid_running

    def rfid_service(self, action):
        self.rfid_actions.append(action)
        self.openrfid_running = action == 'start'

    def apply_rfid_support(self):
        # The firmware service produces a symlink on the printer. Most virtual
        # transactions use its identical content because Windows denies links.
        self.rfid_actions.append('apply')
        self.external_ready()

    def external_ready(self):
        I.require(I.filament_detection(self.read(I.EXTENDED_CONFIG)) == 'external'
                  and self.read(I.RFID_LINK) == self.read(I.RFID_TWEAK)
                  and not self.openrfid_running, 'External detection is not active')

    def snapshot(self):
        s = copy.deepcopy(self.initial)
        cfg = self.read(I.ACE_CONFIG)
        if cfg is not None:
            parser = I.configparser.RawConfigParser(inline_comment_prefixes=('#', ';'))
            parser.read_string(cfg.decode())
            values = {k: parser.get('ace', k) for k in I.CONFIG_KEYS if parser.has_option('ace', k)}
            for key in values:
                if key != 'serial': values[key] = int(values[key])
            s['configfile']['settings']['ace'] = values
            if self.read(I.RFID_LINK) == self.read(I.RFID_TWEAK):
                s['configfile']['settings']['fm175xx_reader'] = {'enabled': False}
            s['ace'] = {'connected': True, 'status_fresh': True, 'status': 'ready',
                'last_error': None, 'feed_assist_index': -1, 'preload_queue': [],
                'dryer_status': {'status': 'stop'}, 'rfid_sync': [None]*4,
                'gate_status': [0, 0, 0, 0], 'port_version': 'port7' if self.active else 'prior'}
        if self.snapshot_override:
            self.snapshot_override(s)
        return s

    def service_action(self, action):
        self.actions.append(action)
        if action == 'start':
            self.active = self.read(I.DESTINATIONS['ace.py']) is not None

    def write(self, name, data, metadata=None):
        if self.fail_write == name:
            self.fail_write = None
            raise OSError('simulated atomic-write failure')
        if metadata is not None:
            # The virtual printer's root-owned backup files belong to the test
            # account on the host. Keep actual chmod/fsync/replace operations;
            # ordinary Linux CI must not need permission to chown files to root.
            metadata = dict(metadata,
                            uid=os.getuid() if hasattr(os, 'getuid') else metadata['uid'],
                            gid=os.getgid() if hasattr(os, 'getgid') else metadata['gid'])
        super().write(name, data, metadata)


class Fixture:
    def __init__(self, directory):
        self.base = Path(directory)
        self.bundle = self.base / 'bundle'; self.bundle.mkdir()
        (self.bundle / 'payload').mkdir()
        self.host = FakeHost(self.base / 'root')
        self.put('/oem/.printer_data', b'')
        self.put('/identity', b'exact firmware')
        self.put(I.CONFIG_ROOT + '/printer.cfg', b'[printer]\n[include extended/klipper/*.cfg]\n')
        self.put(I.CONFIG_ROOT + '/extended/openrfid_user.cfg', b'private NFC settings\n')
        self.put(I.EXTENDED_CONFIG, b'[web]\nfrontend: fluidd\n\n[components]\nrfid: snapmaker\n')
        self.put(I.RFID_TWEAK, b'[fm175xx_reader]\nenabled: False\n')
        self.manifest = {'schema': 1, 'target_firmware': I.TARGET, 'version': 'port7',
            'firmware_checks': [{'path': '/identity', 'sha256': I.digest(b'exact firmware')}],
            'firmware_markers': [], 'files': []}
        for name, value in (('FULLVERSION', I.TARGET), ('BASE_VERSION', 'base'), ('BUILD_VERSION', 'build')):
            self.put('/etc/' + name, (value + '\n').encode())
            self.manifest['firmware_markers'].append({'path': '/etc/' + name, 'value': value})
        for name, destination in I.DESTINATIONS.items():
            new = ACE if name == 'ace.py' else ('# reviewed ' + name + '\n').encode()
            old = None if name == 'ace.py' else ('# original ' + name + '\n').encode()
            (self.bundle / 'payload' / name).write_bytes(new)
            if old is not None: self.put(destination, old)
            self.manifest['files'].append({'id': name, 'payload': 'payload/' + name,
                'destination': destination, 'sha256': I.digest(new),
                'accepted_source_sha256': [I.digest(old) if old is not None else None]})
        self.write_manifest()
        self.installer = I.Installer(self.bundle, self.host)
        self.settings = dict(I.DEFAULTS, calibrated_acknowledged=True)

    def put(self, name, data):
        p = self.host.path(name); p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)

    def write_manifest(self):
        (self.bundle / 'manifest.json').write_bytes(I.json_bytes(self.manifest))

    def bytes(self):
        return {str(p.relative_to(self.host.root)): p.read_bytes()
                for p in self.host.root.rglob('*') if p.is_file() and 'ultimate-u1-ace-link' not in str(p)}

    def install(self):
        with patch.object(I.time, 'sleep', return_value=None):
            return self.installer.install(self.settings)


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.f = Fixture(self.temp.name)

    def test_virtual_root_ownership_maps_to_test_account_without_skipping_write(self):
        with patch.object(I.os, 'getuid', return_value=1234, create=True), \
                patch.object(I.os, 'getgid', return_value=5678, create=True), \
                patch.object(I.os, 'chown', create=True) as chown, \
                patch.object(I.os, 'chmod', wraps=I.os.chmod) as chmod:
            self.f.host.write('/ownership-test', b'atomic bytes',
                              {'mode': 0o600, 'uid': 0, 'gid': 0})
        self.assertEqual(self.f.host.read('/ownership-test'), b'atomic bytes')
        chown.assert_called_once()
        self.assertEqual(chown.call_args.args[1:], (1234, 5678))
        chmod.assert_called_once_with(chown.call_args.args[0], 0o600)

    def test_check_does_not_write_or_restart(self):
        before = self.f.bytes(); plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(before, self.f.bytes()); self.assertEqual(self.f.host.actions, [])
        self.assertEqual(plan['settings']['forward_takeup_length'], 0)
        self.assertEqual(plan['changes'][I.DESTINATIONS['ace.py']], ACE)

    def test_clean_install_and_explicit_rollback_restore_original_bytes(self):
        before = self.f.bytes(); outcome = self.f.install()
        self.assertTrue(outcome['installed'])
        self.assertEqual(self.f.host.actions, ['stop', 'start'])
        self.assertIn(b'[save_variables]', self.f.host.read(I.ACE_CONFIG))
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback()
        self.assertEqual(before, self.f.bytes())
        self.assertIsNone(self.f.host.read(I.RECEIPT))

    def ace_transaction(self, state='PREPARED', **changes):
        token = 'a' * 32
        record = dict(schema=1, operation=token, state=state, ready=True,
                      service_restored=True, stopped=False,
                      flash_attempted=state == 'SUCCEEDED')
        record.update(changes)
        base = I.STATE_ROOT + '/ace-firmware'
        self.f.put(base + '/last.json', I.json_bytes({'operation': token}))
        self.f.put(base + '/' + token + '/state.json', I.json_bytes(record))
        return base, token

    def test_ace_safe_terminal_records_allow_host_install_and_rollback(self):
        for state in ('PREPARED', 'ALREADY_TARGET', 'UNSUPPORTED', 'FAILED_SAFE',
                      'CANCELLED_SAFE', 'SUCCEEDED'):
            with self.subTest(state=state):
                self.ace_transaction(state)
                self.f.installer.ace_maintenance_clear()
        base, token = self.ace_transaction('SUCCEEDED')
        path = base + '/' + token + '/state.json'
        evidence = self.f.host.read(path)
        self.f.install()
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback()
        self.assertEqual(self.f.host.read(path), evidence)

    def test_ace_active_or_uncertain_record_blocks_both_mutating_entries(self):
        for state in ('PREPARING', 'STARTING', 'RUNNING', 'RECOVERING',
                      'NEEDS_ATTENTION', 'UNKNOWN', '', None, []):
            with self.subTest(state=state):
                self.ace_transaction(state)
                with patch.object(self.f.installer, 'prepare') as prepare, \
                        patch.object(self.f.installer, 'firmware') as firmware:
                    with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
                        self.f.installer.install(self.f.settings)
                    with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
                        self.f.installer.rollback(offline_recovery=True, confirm_idle_and_cold=True)
                    prepare.assert_not_called(); firmware.assert_not_called()
                self.assertEqual(self.f.host.actions, [])

    def test_ace_terminal_requires_complete_consistent_restoration_evidence(self):
        mutations = [dict(ready=False), dict(ready=1), dict(service_restored=False),
                     dict(service_restored=None), dict(stopped=True), dict(stopped=None),
                     dict(flash_attempted=True), dict(flash_attempted=0),
                     dict(schema=True), dict(schema=2), dict(operation='b' * 32)]
        for change in mutations:
            with self.subTest(change=change):
                self.ace_transaction(**change)
                with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
                    self.f.installer.ace_maintenance_clear()
        self.ace_transaction('SUCCEEDED', flash_attempted=False)
        with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
            self.f.installer.ace_maintenance_clear()

    def test_ace_corrupt_missing_and_oversized_records_fail_closed(self):
        base, token = self.ace_transaction()
        pointer, state = base + '/last.json', base + '/' + token + '/state.json'
        cases = [(pointer, b'not JSON'), (pointer, b'[]'),
                 (pointer, I.json_bytes({'operation': '../escape'})),
                 (pointer, b' ' * 1025), (state, b'{'), (state, b'null'),
                 (state, b' ' * 65537)]
        for path, value in cases:
            with self.subTest(path=path, size=len(value)):
                self.ace_transaction(); self.f.put(path, value)
                with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
                    self.f.installer.ace_maintenance_clear()
        self.ace_transaction(); self.f.host.path(state).unlink()
        with self.assertRaisesRegex(RuntimeError, 'ACE firmware operation'):
            self.f.installer.ace_maintenance_clear()

    def test_ace_state_paths_cannot_follow_symlinks(self):
        base, token = self.ace_transaction()
        state = self.f.host.path(base + '/' + token + '/state.json')
        target = self.f.base / 'external-state.json'
        target.write_bytes(state.read_bytes()); state.unlink()
        try:
            state.symlink_to(target)
        except OSError as exc:
            self.skipTest('Platform does not permit test symlinks: ' + str(exc))
        with self.assertRaisesRegex(RuntimeError, 'Unexpected symlink'):
            self.f.installer.ace_maintenance_clear()
        self.assertEqual(self.f.host.actions, [])

    def test_read_only_prepare_remains_available_during_ace_attention(self):
        self.ace_transaction('NEEDS_ATTENTION')
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['forward_takeup_length'], 0)
        self.assertEqual(self.f.host.actions, [])

    def test_acknowledgement_is_required_before_mutation(self):
        self.f.settings['calibrated_acknowledged'] = False
        before = self.f.bytes()
        with self.assertRaisesRegex(RuntimeError, 'calibrated_acknowledged'):
            self.f.install()
        self.assertEqual(before, self.f.bytes()); self.assertEqual(self.f.host.actions, [])

    def test_unknown_core_and_wrong_firmware_fail_before_service(self):
        for path in (I.DESTINATIONS['extruder.py'], '/identity', '/etc/FULLVERSION'):
            with self.subTest(path=path):
                original = self.f.host.read(path); self.f.put(path, b'unreviewed')
                with self.assertRaises(RuntimeError): self.f.install()
                self.assertEqual(self.f.host.actions, []); self.f.put(path, original)

    def test_tampered_payload_is_not_installed(self):
        p = self.f.bundle / 'payload' / 'ace.py'; p.write_bytes(ACE + b'# changed\n')
        with self.assertRaisesRegex(RuntimeError, 'Payload hash'): self.f.install()
        self.assertEqual(self.f.host.actions, [])

    def test_active_print_or_heat_is_refused(self):
        for condition in ('printing', 'heating'):
            with self.subTest(condition=condition):
                def change(s):
                    if condition == 'printing': s['print_stats']['state'] = 'printing'
                    else: s['extruder']['target'] = 210
                self.f.host.snapshot_override = change
                with self.assertRaises(RuntimeError): self.f.install()
                self.assertEqual(self.f.host.actions, [])

    def test_partial_write_failure_rolls_back_all_files(self):
        before = self.f.bytes(); self.f.host.fail_write = I.DESTINATIONS['filament_detect.py']
        with patch.object(I.time, 'sleep', return_value=None):
            with self.assertRaisesRegex(OSError, 'simulated'):
                self.f.installer.install(self.f.settings)
        self.assertEqual(before, self.f.bytes())
        self.assertEqual(self.f.host.actions, ['stop', 'stop', 'start'])

    def test_ready_failure_restores_all_originals(self):
        before = self.f.bytes(); real_ready = self.f.installer.ready
        def reject_new(before, version=None, settings=None, timeout=110):
            if version: raise RuntimeError('simulated new startup failure')
            return real_ready(before, version, settings, timeout)
        self.f.installer.ready = reject_new
        with patch.object(I.time, 'sleep', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'new startup failure'):
                self.f.installer.install(self.f.settings)
        self.assertEqual(before, self.f.bytes())
        self.assertEqual(self.f.host.actions, ['stop', 'start', 'stop', 'start'])

    def test_new_values_only_replace_existing_when_explicitly_selected(self):
        original = I.patch_ace_config(None, {k: I.DEFAULTS[k] for k in I.CONFIG_KEYS}, True)
        original = original.replace(b'retract_length: 1250', b'retract_length: 1400 # measured')
        original += b'\n[gcode_macro USER_MACRO]\ngcode:\n    M118 retained\n'
        self.f.put(I.ACE_CONFIG, original)
        self.f.put(I.CONFIG_ROOT + '/ace_vars.cfg', b'[Variables]\nmy_value = 42\n')
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['retract_length'], 1400)
        self.assertIn(b'# measured', plan['changes'][I.ACE_CONFIG])
        self.assertIn(b'USER_MACRO', plan['changes'][I.ACE_CONFIG])
        self.assertEqual(plan['changes'][I.ACE_CONFIG].count(b'[save_variables]'), 1)
        self.assertNotIn(I.CONFIG_ROOT + '/ace_vars.cfg', plan['changes'])
        self.f.settings.update(apply_existing_settings=True, forward_takeup_length=300)
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['retract_length'], 1250)
        self.assertEqual(plan['settings']['forward_takeup_length'], 300)

    def test_existing_separate_save_variables_is_reused_without_duplicate(self):
        self.f.put(I.CONFIG_ROOT + '/extended/klipper/other.cfg',
                   b'[save_variables]\nfilename: ' + (I.CONFIG_ROOT + '/other-vars.cfg').encode() + b'\n')
        self.f.put(I.CONFIG_ROOT + '/other-vars.cfg', b'[Variables]\nuser_value = 7\n')
        plan = self.f.installer.prepare(self.f.settings)
        self.assertNotIn(b'[save_variables]', plan['changes'][I.ACE_CONFIG])
        self.assertIn(I.CONFIG_ROOT + '/other-vars.cfg', plan['protected'])

    def test_duplicate_save_variables_or_unexpected_ace_section_refused(self):
        self.f.put(I.CONFIG_ROOT + '/extended/klipper/other.cfg', b'[ace]\nserial: /dev/ttyACM0\n')
        with self.assertRaisesRegex(RuntimeError, 'unexpected or duplicate'):
            self.f.installer.prepare(self.f.settings)

    def test_configured_constants_are_exact_and_retained_on_managed_update(self):
        self.f.settings.update(fast_load_length=1000, fast_load_speed=150,
                               sensor_load_speed=40, sensor_load_max_length=2200)
        self.f.install()
        data = self.f.host.read(I.DESTINATIONS['ace.py'])
        self.assertIn(b'FAST_LOAD_LENGTH = 1000', data)
        plan = self.f.installer.prepare(dict(I.DEFAULTS, calibrated_acknowledged=True))
        self.assertEqual(plan['changes'][I.DESTINATIONS['ace.py']], data)

    def test_modified_managed_core_blocks_reinstall_and_rollback(self):
        self.f.install(); self.f.host.actions.clear()
        self.f.put(I.DESTINATIONS['ace.py'], b'# unknown local edit\n')
        with self.assertRaisesRegex(RuntimeError, 'Unknown modified core'): self.f.install()
        with self.assertRaisesRegex(RuntimeError, 'Installed files changed'): self.f.installer.rollback()
        self.assertEqual(self.f.host.actions, [])

    def test_settings_limits_and_injection_are_refused(self):
        for kwargs in ({'forward_takeup_length': 501}, {'fast_load_speed': 201},
                       {'sensor_load_speed': 51}, {'serial': '/dev/ttyACM0\n[gcode_macro BAD]'},
                       {'retract_length': 100}, {'fast_load_length': True},
                       {'calibrated_acknowledged': 'true'}):
            with self.subTest(kwargs=kwargs):
                with self.assertRaises(RuntimeError): I.validate_settings(dict(I.DEFAULTS, **kwargs))

    def test_missing_include_and_duplicate_include_fail_closed(self):
        for data in (b'[printer]\n',
                     b'[include extended/klipper/*.cfg]\n[include extended/klipper/*.cfg]\n'):
            self.f.put(I.CONFIG_ROOT + '/printer.cfg', data)
            self.f.put(I.CONFIG_ROOT + '/extended/klipper/one.cfg', b'[test]\n')
            with self.assertRaises(RuntimeError): self.f.installer.prepare(self.f.settings)

    def test_only_official_printer_data_symlink_mapping_is_allowed(self):
        source = self.f.host.root / 'home/lava/printer_data'
        target = self.f.host.root / 'oem/printer_data'
        source.rename(target)
        try:
            source.symlink_to(target, target_is_directory=True)
        except OSError as exc:
            self.skipTest('Platform does not permit test symlinks: ' + str(exc))
        self.assertEqual(self.f.host.read(I.CONFIG_ROOT + '/printer.cfg'),
                         (target / 'config/printer.cfg').read_bytes())
        self.f.installer.prepare(self.f.settings)
        source.unlink()
        other = self.f.host.root / 'unexpected'; other.mkdir()
        source.symlink_to(other, target_is_directory=True)
        with self.assertRaisesRegex(RuntimeError, 'Unexpected symlink'):
            self.f.host.read(I.CONFIG_ROOT + '/printer.cfg')

    def test_offline_recovery_requires_local_ack_and_recovers_without_receipt(self):
        before = self.f.bytes(); result = self.f.install()
        self.f.host.path(I.RECEIPT).unlink()
        original_state = self.f.host.state_reader
        self.f.host.state_reader = lambda: (_ for _ in ()).throw(RuntimeError('API unavailable'))
        with self.assertRaisesRegex(RuntimeError, 'confirm-idle-and-cold'):
            self.f.installer.rollback(result['backup'], offline_recovery=True)
        previous_service = self.f.host.service_runner
        def service(action):
            previous_service(action)
            if action == 'start': self.f.host.state_reader = original_state
        self.f.host.service_runner = service
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback(result['backup'], offline_recovery=True, confirm_idle_and_cold=True)
        self.assertEqual(before, self.f.bytes())

    def test_offline_flag_does_not_override_known_active_print(self):
        self.f.install(); self.f.host.actions.clear()
        self.f.host.snapshot_override = lambda s: s['print_stats'].update(state='printing')
        with self.assertRaisesRegex(RuntimeError, 'Printer must be idle'):
            self.f.installer.rollback(offline_recovery=True, confirm_idle_and_cold=True)
        self.assertEqual(self.f.host.actions, [])

    def test_corrupt_backup_is_rejected_before_stopping_service(self):
        result = self.f.install(); self.f.host.actions.clear()
        self.f.put(I.STATE_ROOT + '/backups/' + result['backup'] + '/1', b'bad backup')
        with self.assertRaisesRegex(RuntimeError, 'Backup content mismatch'):
            self.f.installer.rollback()
        self.assertEqual(self.f.host.actions, [])

    def test_fresh_install_requires_empty_heads_before_any_mutation(self):
        self.f.host.initial['filament_motion_sensor e0_filament']['filament_detected'] = True
        with self.assertRaisesRegex(RuntimeError, 'all four U1 heads empty'):
            self.f.install()
        self.assertEqual(self.f.host.actions, [])

    def test_fresh_empty_slot_metadata_initialization_is_reported(self):
        def update(s):
            if self.f.host.active:
                s['print_task_config']['filament_vendor_0'] = 'Generic'
        self.f.host.snapshot_override = update
        result = self.f.install()
        self.assertTrue(result['fresh_install'])
        self.assertTrue(result['empty_slot_metadata_initialized'])

    def test_existing_ace_metadata_change_is_not_accepted(self):
        self.f.install()
        before = self.f.host.state()
        self.f.host.snapshot_override = lambda s: s['print_task_config'].update(filament_vendor_0='Changed')
        with patch.object(I.time, 'monotonic', side_effect=[0, 0, 200]), patch.object(I.time, 'sleep'):
            with self.assertRaisesRegex(RuntimeError, 'Material metadata changed'):
                self.f.installer.ready(before, 'port7', self.f.settings)

    def test_failed_install_reports_backup_and_verified_restoration(self):
        before = self.f.bytes()
        self.f.host.fail_write = I.DESTINATIONS['filament_detect.py']
        output = io.StringIO()
        with contextlib.redirect_stderr(output), patch.object(I.time, 'sleep', return_value=None):
            with self.assertRaisesRegex(OSError, 'simulated atomic-write failure'):
                self.f.installer.install(self.f.settings)
        self.assertEqual(before, self.f.bytes())
        text = output.getvalue()
        self.assertRegex(text, r'Backup ID: \d{8}T\d{12}Z')
        self.assertIn('Backup directory: ' + I.STATE_ROOT + '/backups/', text)
        self.assertIn('Automatic rollback VERIFIED', text)
        self.assertIn('Original installation error: OSError: simulated atomic-write failure', text)

    def test_failed_restoration_reports_both_errors_and_backup_id(self):
        self.f.host.fail_write = I.DESTINATIONS['filament_detect.py']
        def failed_restore(*args, **kwargs):
            raise RuntimeError('simulated restoration failure')
        self.f.installer.restore = failed_restore
        output = io.StringIO()
        with contextlib.redirect_stderr(output):
            with self.assertRaisesRegex(RuntimeError, 'simulated atomic-write failure.*simulated restoration failure') as caught:
                self.f.installer.install(self.f.settings)
        self.assertIsInstance(caught.exception.__cause__, OSError)
        self.assertIn('automatic rollback FAILED', output.getvalue())
        self.assertRegex(output.getvalue(), r'Backup ID: \d{8}T\d{12}Z')

    def test_external_automatic_setup_preserves_other_settings_and_private_keys(self):
        original = (b'[web]\r\nfrontend: fluidd\r\n\r\n[components]\r\n'
                    b'rfid: openrfid\r\nother_option: keep\r\n\r\n[remote_access]\r\nssh: true\r\n')
        self.f.put(I.EXTENDED_CONFIG, original)
        self.f.host.openrfid_running = True
        secret = self.f.host.read(I.CONFIG_ROOT + '/extended/openrfid_user.cfg')
        before = self.f.bytes()
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(self.f.bytes(), before)
        self.assertEqual(self.f.host.rfid_actions, [])
        self.assertEqual(plan['rfid_before'], {'mode': 'openrfid', 'running': True})
        self.f.install()
        self.assertEqual(self.f.host.read(I.EXTENDED_CONFIG), original.replace(b'rfid: openrfid', b'rfid: external'))
        self.assertEqual(self.f.host.read(I.CONFIG_ROOT + '/extended/openrfid_user.cfg'), secret)
        self.assertEqual(self.f.host.rfid_actions, ['stop', 'apply'])
        self.assertFalse(self.f.host.openrfid_running)
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback()
        self.assertEqual(self.f.bytes(), before)
        self.assertTrue(self.f.host.openrfid_running)
        self.assertEqual(self.f.host.rfid_actions, ['stop', 'apply', 'stop', 'start'])

    def test_rollback_does_not_start_previously_stopped_openrfid(self):
        self.f.put(I.EXTENDED_CONFIG, b'[components]\nrfid: openrfid-generic\n')
        self.f.host.openrfid_running = False
        before = self.f.bytes(); self.f.install()
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback()
        self.assertEqual(self.f.bytes(), before)
        self.assertFalse(self.f.host.openrfid_running)
        self.assertNotIn('start', self.f.host.rfid_actions)

    def test_failed_external_activation_restores_mode_service_and_configs(self):
        self.f.put(I.EXTENDED_CONFIG, b'[components]\nrfid: openrfid\n')
        self.f.host.openrfid_running = True
        before = self.f.bytes()
        self.f.host.apply_rfid_support = lambda: (_ for _ in ()).throw(RuntimeError('RFID activation failed'))
        with patch.object(I.time, 'sleep', return_value=None):
            with self.assertRaisesRegex(RuntimeError, 'RFID activation failed'):
                self.f.installer.install(self.f.settings)
        self.assertEqual(self.f.bytes(), before)
        self.assertTrue(self.f.host.openrfid_running)

    def test_automatic_serial_requires_one_candidate_even_if_default_exists(self):
        for candidates in ([], [I.DEFAULTS['serial'], '/dev/serial/by-id/usb-ANYCUBIC_ACE_2-if00']):
            with self.subTest(candidates=candidates):
                self.f.host.candidates = candidates
                with self.assertRaisesRegex(RuntimeError, 'exactly one verified device'):
                    self.f.installer.prepare(self.f.settings)
                self.assertEqual(self.f.host.actions, [])
        self.f.host.candidates = ['/dev/serial/by-id/usb-ANYCUBIC_ACE_2-if00']
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['serial'], self.f.host.candidates[0])
        self.assertEqual(plan['serial_selection'], 'auto_discovered')
        self.f.host.candidates = [I.DEFAULTS['serial'], '/dev/serial/by-id/usb-ANYCUBIC_ACE_2-if00']
        self.f.settings['auto_detect_serial'] = False
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['serial'], I.DEFAULTS['serial'])
        self.assertEqual(plan['serial_selection'], 'explicit_setting')

    def test_existing_or_explicit_serial_is_preserved_without_auto_selection(self):
        self.f.host.candidates = []
        self.f.settings['serial'] = '/dev/custom-ace'
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['serial'], '/dev/custom-ace')
        self.assertEqual(plan['serial_selection'], 'explicit_setting')
        self.f.put(I.ACE_CONFIG, I.patch_ace_config(None, {k: self.f.settings[k] for k in I.CONFIG_KEYS}, True))
        self.f.settings.update(serial=I.DEFAULTS['serial'], apply_existing_settings=True)
        plan = self.f.installer.prepare(self.f.settings)
        self.assertEqual(plan['settings']['serial'], '/dev/custom-ace')
        self.assertEqual(plan['serial_selection'], 'existing_config')

    def test_reader_symlink_is_preserved_by_backup_and_rollback(self):
        reader = self.f.host.path(I.RFID_LINK)
        reader.parent.mkdir(parents=True, exist_ok=True)
        target = self.f.host.path(I.RFID_TWEAK)
        try:
            reader.symlink_to(target)
        except OSError as exc:
            self.skipTest('Platform does not permit test symlinks: ' + str(exc))
        self.f.put(I.EXTENDED_CONFIG, b'[components]\nrfid: external\n')
        def native_link():
            self.f.host.restore_rfid_link(str(target))
            I.Host.external_ready(self.f.host)
        self.f.host.apply_rfid_support = native_link
        self.f.install()
        self.assertTrue(reader.is_symlink())
        with patch.object(I.time, 'sleep', return_value=None):
            self.f.installer.rollback()
        self.assertTrue(reader.is_symlink())
        self.assertEqual(os.readlink(reader), str(target))

    def test_unknown_reader_override_and_running_pid_are_rejected(self):
        self.f.put(I.RFID_LINK, b'[fm175xx_reader]\nenabled: True\n')
        with self.assertRaisesRegex(RuntimeError, 'Custom disable-rfid-reader'):
            self.f.installer.prepare(self.f.settings)
        self.f.put('/var/run/openrfid.pid', b'12345\n')
        self.f.put('/proc/12345/cmdline', b'/usr/bin/python3\0some-other-service.py\0')
        with self.assertRaisesRegex(RuntimeError, 'belongs to another process'):
            I.Host.rfid_running(self.f.host)

    def put_daemon(self, pid=12345, registered=True):
        self.f.put('/proc/%d/cmdline' % pid,
                   b'/usr/bin/python3\0/usr/local/bin/openrfid.py\0/tmp/openrfid.cfg\0')
        if registered:
            self.f.put('/var/run/openrfid.pid', (str(pid) + '\n').encode())

    def test_deleted_pid_file_does_not_prove_stop_or_external_activation(self):
        self.put_daemon()
        host = self.f.host
        def native_stop(*args, **kwargs):
            host.path('/var/run/openrfid.pid').unlink()
        clock = itertools.count(0, .5)
        with patch.object(I.subprocess, 'run', side_effect=native_stop) as run, \
                patch.object(I.time, 'monotonic', side_effect=lambda: next(clock)), \
                patch.object(I.time, 'sleep'):
            with self.assertRaisesRegex(RuntimeError, 'service state did not settle'):
                I.Host.rfid_service(host, 'stop')
        run.assert_called_once()
        self.assertEqual(run.call_args.args[0], ['/etc/init.d/S99openrfid', 'stop'])
        self.assertTrue(host.path('/proc/12345/cmdline').exists())
        with self.assertRaisesRegex(RuntimeError, 'Orphan OpenRFID'):
            I.Host.rfid_running(host)
        self.f.put(I.EXTENDED_CONFIG, b'[components]\nrfid: external\n')
        original_path = host.path
        valid_link = Mock(); valid_link.is_symlink.return_value = True
        target = str(original_path(I.RFID_TWEAK))
        with patch.object(host, 'path', side_effect=lambda name: valid_link if name == I.RFID_LINK else original_path(name)), \
                patch.object(I.os, 'readlink', return_value=target), \
                patch.object(host, 'rfid_running', side_effect=lambda: I.Host.rfid_running(host)):
            with self.assertRaisesRegex(RuntimeError, 'Orphan OpenRFID'):
                I.Host.external_ready(host)

    def test_stop_waits_for_original_process_to_exit_after_pid_file_removal(self):
        self.put_daemon()
        host = self.f.host
        def native_stop(*args, **kwargs):
            host.path('/var/run/openrfid.pid').unlink()
        waits = []
        def delayed_exit(delay):
            waits.append(delay)
            if len(waits) == 2:
                host.path('/proc/12345/cmdline').unlink()
        clock = itertools.count(0, .2)
        with patch.object(I.subprocess, 'run', side_effect=native_stop), \
                patch.object(I.time, 'monotonic', side_effect=lambda: next(clock)), \
                patch.object(I.time, 'sleep', side_effect=delayed_exit):
            I.Host.rfid_service(host, 'stop')
        self.assertEqual(waits, [.1, .1])
        self.assertFalse(I.Host.rfid_running(host))

    def test_orphan_multiple_and_unowned_daemons_are_never_signalled(self):
        self.put_daemon(registered=False)
        with patch.object(I.subprocess, 'run') as run:
            with self.assertRaisesRegex(RuntimeError, 'Orphan OpenRFID'):
                I.Host.rfid_service(self.f.host, 'stop')
            self.put_daemon()
            self.put_daemon(12346, registered=False)
            with self.assertRaisesRegex(RuntimeError, 'Multiple OpenRFID'):
                I.Host.rfid_service(self.f.host, 'stop')
            self.f.host.path('/proc/12346/cmdline').unlink()
            self.f.put('/proc/12345/cmdline', b'/usr/bin/python3\0-u\0/usr/local/bin/openrfid.py\0')
            with self.assertRaisesRegex(RuntimeError, 'belongs to another process'):
                I.Host.rfid_service(self.f.host, 'stop')
            run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
