import logging, copy, os
from . import pulse_counter


FEED_CHANNEL_NUMS                                   = 2
FEED_ACE_REFILL_READY_TIMEOUT                       = 180
FEED_CHANNEL_1                                      = 0
FEED_CHANNEL_2                                      = 1

FEED_OK                                             = 'ok'
FEED_ERR                                            = 'general'
FEED_ERR_PARAMETER                                  = 'parameter'
FEED_ERR_TIMEOUT                                    = 'timeout'
FEED_ERR_NO_FILAMENT                                = 'no_filament'
FEED_ERR_RESIDUAL_FILAMENT                          = 'residual_filament'
FEED_ERR_MOTOR_SPEED                                = 'motor_speed'
FEED_ERR_WHEEL_SPEED                                = 'wheel_speed'
FEED_ERR_MOVE                                       = 'move'
FEED_ERR_MOVE_HOME                                  = 'move_home'
FEED_ERR_MOVE_SWITCH                                = 'move_switch'
FEED_ERR_MOVE_EXTRUDE                               = 'move_extrude'
FEED_ERR_CUSTOM_GCODE                               = 'custom_gcode'
FEED_ERR_DISTANCE                                   = 'distance'
FEED_ERR_STATE_MISMATCH                             = 'state_mismatch'
FEED_ERR_HEAT                                       = 'heat'

FEED_ACT_PRELOAD                                    = 'preload'
FEED_ACT_LOAD                                       = 'load'
FEED_ACT_UNLOAD                                     = 'unload'
FEED_ACT_MANUAL_FEED                                = 'manual_feed'
FEED_ACT_UPDATE_AUTO_MODE                           = 'update_auto_mode'
FEED_ACT_REMOVE_FILAMENT                            = 'remove_filament'
FEED_ACT_FILAMENT_RUNOUT                            = 'filament_runout'

FEED_STA_NONE                                       = 'none'
FEED_STA_INITED                                     = 'inited'
FEED_STA_WAIT_INSERT                                = 'wait_insert'
FEED_STA_PRELOAD_PREPARE                            = 'preload_prepare'
FEED_STA_PRELOAD_FEEDING                            = 'preload_feeding'
FEED_STA_PRELOAD_FINISH                             = 'preload_finish'
FEED_STA_PRELOAD_FAIL                               = 'preload_fail'
FEED_STA_LOAD_PREPARE                               = 'load_prepare'
FEED_STA_LOAD_HOMING                                = 'load_homing'
FEED_STA_LOAD_PICKING                               = 'load_picking'
FEED_STA_LOAD_HEATING                               = 'load_heating'
FEED_STA_LOAD_FEEDING                               = 'load_feeding'
FEED_STA_LOAD_EXTRUDING                             = 'load_extruding'
FEED_STA_LOAD_FLUSHING                              = 'load_flushing'
FEED_STA_LOAD_FINISH                                = 'load_finish'
FEED_STA_LOAD_FAIL                                  = 'load_fail'
FEED_STA_UNLOAD_PREPARE                             = 'unload_prepare'
FEED_STA_UNLOAD_HOMING                              = 'unload_homing'
FEED_STA_UNLOAD_PICKING                             = 'unload_picking'
FEED_STA_UNLOAD_HEATING                             = 'unload_heating'
FEED_STA_UNLOAD_HEAT_FINISH                         = 'unload_heat_finish'
FEED_STA_UNLOAD_DOING                               = 'unload_doing'
FEED_STA_UNLOAD_FINISH                              = 'unload_finish'
FEED_STA_UNLOAD_FAIL                                = 'unload_fail'
FEED_STA_MANUAL_PREPARE                             = 'manual_sta_prepare'
FEED_STA_MANUAL_HOMING                              = 'manual_sta_homing'
FEED_STA_MANUAL_PICKING                             = 'manual_sta_picking'
FEED_STA_MANUAL_PREPARE_FINISH                      = 'manual_sta_prepare_finish'
FEED_STA_MANUAL_PREPARE_FAIL                        = 'manual_sta_prepare_fail'
FEED_STA_MANUAL_HEATING                             = 'manual_sta_heating'
FEED_STA_MANUAL_EXTRUDING                           = 'manual_sta_extruding'
FEED_STA_MANUAL_EXTRUDE_FINISH                      = 'manual_sta_extrude_finish'
FEED_STA_MANUAL_EXTRUDE_FAIL                        = 'manual_sta_extrude_fail'
FEED_STA_MANUAL_FLUSHING                            = 'manual_sta_flushing'
FEED_STA_MANUAL_FLUSH_FINISH                        = 'manual_sta_flush_finish'
FEED_STA_MANUAL_FLUSH_FAIL                          = 'manual_sta_flush_fail'
FEED_STA_MANUAL_FINISH                              = 'manual_sta_finish'
FEED_STA_MANUAL_FAIL                                = 'manual_sta_fail'
FEED_STA_TEST                                       = 'test'

FEED_MANUAL_STAGE_PREPARE                           = 'prepare'
FEED_MANUAL_STAGE_EXTRUDE                           = 'extrude'
FEED_MANUAL_STAGE_FLUSH                             = 'flush'
FEED_MANUAL_STAGE_FINISH                            = 'finish'
FEED_MANUAL_STAGE_CANCEL                            = 'cancel'
FEED_UNLOAD_STAGE_PREPARE                           = 'prepare'
FEED_UNLOAD_STAGE_DOING                             = 'doing'
FEED_UNLOAD_STAGE_CANCEL                            = 'cancel'

FEED_LIGHT_PWM_CYCLE_TIME                           = 1
FEED_LIGHT_INDEXS                                   = ['RED', 'WHITE', 'ALL']

FEED_PORT_ADC_SAMPLE_TIME                           = 0.05
FEED_PORT_ADC_SAMPLE_COUNT                          = 4
FEED_PORT_ADC_REPORT_TIME                           = 0.300
FEED_PORT_ADC_VAL_THRESHOLD                         = 0.18
FEED_PORT_ADC_VAL_MODULE_EXIST                      = 0.9
FEED_PORT_ADC_DEBOUNCE_COUNT                         = 2

FEED_MOTOR_DIR_IDLE                                 = 0
FEED_MOTOR_DIR_A                                    = 1
FEED_MOTOR_DIR_B                                    = 2

FEED_MOTOR_HARD_PROTECT_TIME                        = 2.5
FEED_MOTOR_SLIP_RATE                                = 0.7
FEED_MOTOR_REDUCTION_R                              = 33.0
FEED_WHEEL_CIRCUMFERENCE                            = 31.4159

FEED_PRELOAD_LENGTH                                 = 950.0
FEED_PRELOAD_TIMEOUT_TIME                           = 45
FEED_PRELOAD_MOTOR_MIN_SPEED                        = 200
FEED_PRELOAD_WHEEL_ERR_CNT_MAX                      = 3
FEED_PRELOAD_MOTOR_ERR_CNT_MAX                      = 2
FEED_LOAD_POSITION_X                                = 150
FEED_LOAD_POSITION_Y                                = 5
FEED_LOAD_LENGTH_MAX                                = 1100.0
FEED_LOAD_TIMEOUT_TIME                              = 60
FEED_LOAD_MOTOR_ERR_CNT_MAX                         = 20
FEED_LOAD_WHEEL_ERR_CNT_MAX                         = 20
FEED_LOAD_EXTRUDE_TIMES_MAX                         = 20

FEED_MOTOR_SPEED_SLOW_SWITCHING                     = 0.45
FEED_MOTOR_SPEED_PRELOAD                            = 0.7
FEED_MOTOR_SPEED_LOAD                               = 0.7
FEED_MOTOR_SPEED_EXTRUDE                            = 0.50
FEED_MOTOR_SPEED_HANG_NEUTRAL_A                     = 1
FEED_MOTOR_SPEED_HANG_NEUTRAL_B                     = 0.9
FEED_MOTOR_HANG_NEUTRAL_TIME                        = 0.040

FEED_COIL_FREQ_THERSHOLD_SOFT                       = 800
FEED_COIL_FREQ_THERSHOLD_HARD                       = 1500

FEED_MIN_TIME                                       = 0.100

FEED_CONFIG_FILE_POSTFIX                            = '_filament_feed.json'
FEED_DEFAULT_CONFIG = {
    'auto_mode': [True] * FEED_CHANNEL_NUMS,
    'load_finish': [False] * FEED_CHANNEL_NUMS
}

FEED_FILAMENT_TEMP_DEFAULT                          = 250

class FeedLight:
    def __init__(self, printer, reactor, red_pin, white_pin):
        self.reactor = reactor
        ppins = printer.lookup_object('pins')
        self.red_light = ppins.setup_pin('pwm', red_pin)
        self.red_light.setup_max_duration(0.)
        self.red_light.setup_start_value(0, 0)
        self.red_light.setup_cycle_time(FEED_LIGHT_PWM_CYCLE_TIME, False)
        self.white_light = ppins.setup_pin('pwm', white_pin)
        self.white_light.setup_max_duration(0.)
        self.white_light.setup_start_value(0, 0)
        self.white_light.setup_cycle_time(FEED_LIGHT_PWM_CYCLE_TIME, False)

    def get_mcu(self):
        return self.red_light.get_mcu()

    def set_light_state(self, print_time, state, index=None, value=None):
        if state in [FEED_STA_PRELOAD_PREPARE, FEED_STA_LOAD_PREPARE, FEED_STA_UNLOAD_PREPARE,
                     FEED_STA_MANUAL_PREPARE]:
            self.red_light.set_pwm(print_time, 0, FEED_MIN_TIME)
            self.white_light.set_pwm(print_time, 0.2, FEED_MIN_TIME)
        elif state in [FEED_STA_PRELOAD_FEEDING, FEED_STA_LOAD_HOMING, FEED_STA_LOAD_PICKING,
                       FEED_STA_LOAD_HEATING, FEED_STA_LOAD_FEEDING, FEED_STA_LOAD_EXTRUDING,
                       FEED_STA_LOAD_FLUSHING, FEED_STA_UNLOAD_HOMING, FEED_STA_UNLOAD_PICKING,
                       FEED_STA_UNLOAD_HEAT_FINISH,
                       FEED_STA_UNLOAD_HEATING, FEED_STA_UNLOAD_DOING, FEED_STA_MANUAL_HOMING,
                       FEED_STA_MANUAL_PICKING, FEED_STA_MANUAL_PREPARE_FINISH, FEED_STA_MANUAL_HEATING,
                       FEED_STA_MANUAL_EXTRUDING, FEED_STA_MANUAL_EXTRUDE_FINISH, FEED_STA_MANUAL_FLUSHING,
                       FEED_STA_MANUAL_FLUSH_FINISH]:
            self.red_light.set_pwm(print_time, 0, FEED_MIN_TIME)
            self.white_light.set_pwm(print_time, 0.5, FEED_MIN_TIME)
        elif state in [FEED_STA_PRELOAD_FINISH, FEED_STA_LOAD_FINISH, FEED_STA_UNLOAD_FINISH,
                       FEED_STA_MANUAL_FINISH]:
            self.red_light.set_pwm(print_time, 0, FEED_MIN_TIME)
            self.white_light.set_pwm(print_time, 1, FEED_MIN_TIME)
        elif state in [FEED_STA_PRELOAD_FAIL, FEED_STA_LOAD_FAIL, FEED_STA_UNLOAD_FAIL,
                       FEED_STA_MANUAL_PREPARE_FAIL, FEED_STA_MANUAL_EXTRUDE_FAIL,
                       FEED_STA_MANUAL_FLUSH_FAIL, FEED_STA_MANUAL_FAIL]:
            self.red_light.set_pwm(print_time, 1, FEED_MIN_TIME)
            self.white_light.set_pwm(print_time, 0, FEED_MIN_TIME)
        elif state == FEED_STA_TEST:
            if index == 'RED' and value is not None:
                self.red_light.set_pwm(print_time, value, FEED_MIN_TIME)
            elif index == 'WHITE' and value is not None:
                self.white_light.set_pwm(print_time, value, FEED_MIN_TIME)
            elif index == 'ALL' and value is not None:
                self.red_light.set_pwm(print_time, value, FEED_MIN_TIME)
                self.white_light.set_pwm(print_time, value, FEED_MIN_TIME)
            else:
                pass
        else:
            self.red_light.set_pwm(print_time, 0, FEED_MIN_TIME)
            self.white_light.set_pwm(print_time, 0, FEED_MIN_TIME)

class FeedPort:
    def __init__(self, printer, reactor, pin, threshold, index):
        self.reactor = reactor
        self.index = index
        self.ace = None
        ppins = printer.lookup_object('pins')
        self._port = ppins.setup_pin('adc', pin)
        self._port_adc_value = 0
        self._threshold = threshold
        self._filament_detected = True
        self._last_filament_detected = True
        self._port_event_callback = None
        self._pending_state = True
        self._stable_count = 0

        self._port.setup_adc_sample(FEED_PORT_ADC_SAMPLE_TIME, FEED_PORT_ADC_SAMPLE_COUNT)
        self._port.setup_adc_callback(FEED_PORT_ADC_REPORT_TIME, self._adc_callback)

    def get_mcu(self):
        return self._port.get_mcu()

    def register_cb_2_port_event(self, cb):
        try:
            if callable(cb):
                self._port_event_callback = cb
            else:
                raise TypeError()
        except:
            logging.error("[feed][port]: param[cb] is not a callable function!")

    def _adc_callback(self, read_time, read_value):
        self._port_adc_value = read_value
        current_detected = self._port_adc_value < self._threshold

        if current_detected == self._pending_state:
            if self._stable_count < FEED_PORT_ADC_DEBOUNCE_COUNT:
                self._stable_count += 1
        else:
            self._pending_state = current_detected
            self._stable_count = 1

        if (self._stable_count >= FEED_PORT_ADC_DEBOUNCE_COUNT
                and self._pending_state != self._filament_detected):
            self._filament_detected = self._pending_state
            self._stable_count = 0
            if (self._port_event_callback is not None
                    and self._last_filament_detected != self._filament_detected):
                self._last_filament_detected = self._filament_detected
                self._port_event_callback(self._filament_detected)

    def get_adc_value(self):
        return self._port_adc_value

    def add_ace(self, ace):
        self.ace = ace

    def get_filament_detected(self):
        if self.ace is not None:
            return self.ace.gate_status[self.index] == 1
        return self._filament_detected

class FeedTachometer:
    def __init__(self, printer, pin, ppr, sample_time, poll_time):
        self.frequence = pulse_counter.FrequencyCounter(printer, pin, sample_time, poll_time)
        self.ppr = ppr

    def get_rpm(self):
        rpm = self.frequence.get_frequency()  * 30. / self.ppr
        return rpm

    def get_counts(self):
        return self.frequence.get_count()

    def get_last_report_time(self):
        return self.frequence.get_last_report_time()

class FeedMotorPwmCfg:
    def __init__(self):
        self.a_pin = None
        self.b_pin = None
        self.cycle_time = 0.010
        self.max_value = 1.0

class FeedMotor:
    def __init__(self, printer, reactor, cfg:FeedMotorPwmCfg):
        self.reactor = reactor
        ppins = printer.lookup_object('pins')
        self.max_value = cfg.max_value
        self._motor_a = ppins.setup_pin('pwm', cfg.a_pin)
        self._motor_a.setup_max_duration(0)
        self._motor_a.setup_cycle_time(cfg.cycle_time, False)
        self._motor_a.setup_start_value(0, 0)
        self._motor_b = ppins.setup_pin('pwm', cfg.b_pin)
        self._motor_b.setup_max_duration(0)
        self._motor_b.setup_cycle_time(cfg.cycle_time, False)
        self._motor_b.setup_start_value(0, 0)
        self._mutex_lock = False
        self._dir = FEED_MOTOR_DIR_IDLE

    def get_mcu(self):
        return self._motor_a.get_mcu()

    def _run(self, dir, value):
        systime = self.reactor.monotonic()
        systime += FEED_MIN_TIME
        print_time = self._motor_a.get_mcu().estimated_print_time(systime)
        if FEED_MOTOR_DIR_A == dir:
            self._motor_b.set_pwm(print_time, 0)
            self._motor_a.set_pwm(print_time, value)
        elif FEED_MOTOR_DIR_B == dir:
            self._motor_a.set_pwm(print_time, 0)
            self._motor_b.set_pwm(print_time, value)
        else:
            self._motor_b.set_pwm(print_time, 0)
            self._motor_a.set_pwm(print_time, 0)
        self._last_print_time = print_time = print_time

    def _run_one_cycle(self, dir, value, time):
        systime = self.reactor.monotonic()
        systime += FEED_MIN_TIME
        print_time = self._motor_a.get_mcu().estimated_print_time(systime)
        delta = time
        if FEED_MOTOR_DIR_A == dir:
            self._motor_b.set_pwm(print_time, 0)
            self._motor_a.set_pwm(print_time, value)
            self._motor_a.set_pwm(print_time + delta, 0)
        elif FEED_MOTOR_DIR_B == dir:
            self._motor_a.set_pwm(print_time, 0)
            self._motor_b.set_pwm(print_time, value)
            self._motor_b.set_pwm(print_time + delta, 0)
        self._last_print_time = print_time + delta

    def run(self, dir, value):
        while self._mutex_lock:
            self.reactor.pause(self.reactor.monotonic() + 0.1)
        self._mutex_lock = True

        val = max(0, min(self.max_value, value))
        if val == 0:
            dir = FEED_MOTOR_DIR_IDLE

        while 1:
            if FEED_MOTOR_DIR_IDLE == self._dir:
                if FEED_MOTOR_DIR_IDLE == dir:
                    break
                self._dir = dir
                self._run(dir, val)
                self.reactor.pause(self.reactor.monotonic() + 1.05 * FEED_MIN_TIME)
            else:
                if dir == self._dir:
                    self._run(dir, val)
                    self.reactor.pause(self.reactor.monotonic() + 1.05 * FEED_MIN_TIME)
                else:
                    self._run(FEED_MOTOR_DIR_IDLE, 0)
                    self.reactor.pause(self.reactor.monotonic() + FEED_MOTOR_HARD_PROTECT_TIME)
                    self._dir = FEED_MOTOR_DIR_IDLE
                    if FEED_MOTOR_DIR_IDLE != dir:
                        self._dir = dir
                        self._run(dir, val)
                        self.reactor.pause(self.reactor.monotonic() + 1.05 * FEED_MIN_TIME)
            break
        self._mutex_lock = False

    def run_one_cycle(self, dir, value, time):
        while self._mutex_lock:
            self.reactor.pause(self.reactor.monotonic() + 0.1)
        self._mutex_lock = True

        val = max(0, min(self.max_value, value))
        if val == 0:
            dir = FEED_MOTOR_DIR_IDLE

        while 1:
            if FEED_MOTOR_DIR_IDLE == self._dir:
                if FEED_MOTOR_DIR_IDLE == dir:
                    break
                self._dir = dir
                self._run_one_cycle(dir, val, time)
                self.reactor.pause(self.reactor.monotonic() + 1.05 * (FEED_MIN_TIME + time))
                self._dir = FEED_MOTOR_DIR_IDLE
            else:
                self._run(FEED_MOTOR_DIR_IDLE, 0)
                self.reactor.pause(self.reactor.monotonic() + FEED_MOTOR_HARD_PROTECT_TIME)
                self._dir = FEED_MOTOR_DIR_IDLE
                if FEED_MOTOR_DIR_IDLE != dir:
                    self._dir = dir
                    self._run_one_cycle(dir, val, time)
                    self.reactor.pause(self.reactor.monotonic() + 1.05 * (FEED_MIN_TIME + time))
                    self._dir = FEED_MOTOR_DIR_IDLE
            break
        self._mutex_lock = False

class FilamentFeed:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.reactor = self.printer.get_reactor()
        self.gcode = self.printer.lookup_object('gcode')
        self.ace = None
        self._ace_runout_wait = {}
        self.module_name = config.get_name().split()[1]

        self.channel_active = None
        self.channel_state = [FEED_STA_NONE] * FEED_CHANNEL_NUMS
        self.channel_action_state = [FEED_STA_NONE] * FEED_CHANNEL_NUMS
        self.channel_error_state = [FEED_STA_NONE] * FEED_CHANNEL_NUMS
        self.channel_error = [FEED_OK] * FEED_CHANNEL_NUMS
        self.module_exist = [False] * FEED_CHANNEL_NUMS
        self.manual_feeding = [False] * FEED_CHANNEL_NUMS
        self.exception_code = [0] * FEED_CHANNEL_NUMS

        config_dir = self.printer.get_snapmaker_config_dir()
        config_name = self.module_name + FEED_CONFIG_FILE_POSTFIX
        self.config_path = os.path.join(config_dir, config_name)
        self.config = self.printer.load_snapmaker_config_file(self.config_path, FEED_DEFAULT_CONFIG)

        # extruder channel / filament channel
        self.filament_ch = []
        self.filament_ch.append(config.getint('filament_ch_1'))
        self.filament_ch.append(config.getint('filament_ch_2'))

        # runout sensor
        self.runout_sensor = []
        tmp_obj = self.printer.lookup_object('filament_motion_sensor e%d_filament' % (self.filament_ch[FEED_CHANNEL_1]), None)
        self.runout_sensor.append(tmp_obj)
        tmp_obj = self.printer.lookup_object('filament_motion_sensor e%d_filament' % (self.filament_ch[FEED_CHANNEL_2]), None)
        self.runout_sensor.append(tmp_obj)
        self.filament_detect = self.printer.lookup_object('filament_detect', None)

        # light
        self.light = []
        white_pin = config.get('light_ch_1_white')
        red_pin = config.get('light_ch_1_red')
        tmp_obj = FeedLight(self.printer, self.reactor, white_pin, red_pin)
        self.light.append(tmp_obj)
        white_pin = config.get('light_ch_2_white')
        red_pin = config.get('light_ch_2_red')
        tmp_obj = FeedLight(self.printer, self.reactor, white_pin, red_pin)
        self.light.append(tmp_obj)
        self.gcode.register_mux_command("FEED_LIGHT", "MODULE",
                                self.module_name,
                                self.cmd_FEED_LIGHT)

        # port
        self._port = []
        tmp_pin = config.get('port_ch_1_pin')
        threshold = config.getfloat('port_ch_1_threshold')
        tmp_obj = FeedPort(self.printer, self.reactor, tmp_pin, threshold, self.filament_ch[0])
        tmp_obj.register_cb_2_port_event(self._port_ch1_event_handler)
        self._port.append(tmp_obj)
        tmp_pin = config.get('port_ch_2_pin')
        threshold = config.getfloat('port_ch_2_threshold')
        tmp_obj = FeedPort(self.printer, self.reactor, tmp_pin, threshold, self.filament_ch[1])
        tmp_obj.register_cb_2_port_event(self._port_ch2_event_handler)
        self._port.append(tmp_obj)
        self.gcode.register_mux_command("FEED_PORT", "MODULE",
                                self.module_name,
                                self.cmd_FEED_PORT)

        # wheel
        self.wheel = []
        self.wheel_2 = []
        tmp_pin = config.get('wheel_tach_ch_1_1_pin')
        wheel_tach_ppr = config.getint('wheel_tach_ppr', 6, minval=1)
        poll_time = config.getfloat('wheel_tach_poll_interval', 0.0005, above=0.)
        tmp_obj = FeedTachometer(
                                self.printer,
                                tmp_pin,
                                wheel_tach_ppr,
                                0.100,
                                poll_time)
        self.wheel.append(tmp_obj)

        tmp_pin = config.get('wheel_tach_ch_2_1_pin')
        tmp_obj = FeedTachometer(
                                self.printer,
                                tmp_pin,
                                wheel_tach_ppr,
                                0.100,
                                poll_time)
        self.wheel.append(tmp_obj)

        tmp_pin = config.get('wheel_tach_ch_1_2_pin')
        tmp_obj = FeedTachometer(
                                self.printer,
                                tmp_pin,
                                wheel_tach_ppr,
                                0.100,
                                poll_time)
        self.wheel_2.append(tmp_obj)

        tmp_pin = config.get('wheel_tach_ch_2_2_pin')
        tmp_obj = FeedTachometer(
                                self.printer,
                                tmp_pin,
                                wheel_tach_ppr,
                                0.100,
                                poll_time)
        self.wheel_2.append(tmp_obj)

        self.gcode.register_mux_command("FEED_WHEEL_TACH", "MODULE",
                                self.module_name,
                                self.cmd_FEED_WHEEL_TACH)

        # motor
        motor_cfg = FeedMotorPwmCfg()
        motor_cfg.a_pin = config.get('motor_ch_1_pin')
        motor_cfg.b_pin = config.get('motor_ch_2_pin')
        motor_cfg.cycle_time = config.getfloat('motor_cycle_time')
        motor_cfg.max_value = config.getfloat('motor_max_value', maxval=1.0)
        self.motor = FeedMotor(self.printer, self.reactor, motor_cfg)
        self.gcode.register_mux_command("FEED_MOTOR", "MODULE",
                                self.module_name,
                                self.cmd_FEED_MOTOR)
        self.gcode.register_mux_command("FEED_MOTOR_ONE_CYCLE", "MODULE",
                                self.module_name,
                                self.cmd_FEED_MOTOR_ONE_CYCLE)

        # motor tachometer
        tmp_pin = config.get('motor_tach_pin')
        motor_tach_ppr = config.getint('motor_tach_ppr', 2, minval=1)
        poll_time = config.getfloat('motor_tach_poll_interval', 0.0015, above=0.)
        self.motor_tachometer = FeedTachometer(
                                self.printer,
                                tmp_pin,
                                motor_tach_ppr,
                                0.100,
                                poll_time)
        self.gcode.register_mux_command("FEED_MOTOR_TACH", "MODULE",
                                self.module_name,
                                self.cmd_FEED_MOTOR_TACH)

        # other config
        self._feed_load_position_x = config.getfloat('load_position_x', FEED_LOAD_POSITION_X, minval=2, maxval=265)
        self._feed_load_position_y = config.getfloat('load_position_y', FEED_LOAD_POSITION_Y, minval=2, maxval=250)
        self._feed_load_extrude_max_times = config.getint('load_extrude_max_times', FEED_LOAD_EXTRUDE_TIMES_MAX, minval=3, maxval=50)
        preload_length = config.getfloat('preload_length', FEED_PRELOAD_LENGTH, minval=600.0, maxval=2500.0)
        self.coil_freq_threshold_soft = config.getint('coil_freq_thershold_soft', FEED_COIL_FREQ_THERSHOLD_SOFT, minval=100)
        self.coil_freq_threshold_hard = config.getint('coil_freq_thershold_hard', FEED_COIL_FREQ_THERSHOLD_HARD, minval=100)
        self.check_wheel_data = config.getint('check_wheel_data', 1)
        self.check_coil_freq = config.getint('check_coil_freq', 1)
        if self.check_coil_freq == 0 and self.check_wheel_data == 0:
            raise Exception("check_wheel_data and check_coil_freq can not be both 0")
        self.debug_mode = config.getint('debug_mode', 0)

        # other gcode cmd
        self.gcode.register_mux_command("FEED_AUTO", "MODULE",
                        self.module_name,
                        self.cmd_FEED_AUTO)
        self.gcode.register_mux_command("FEED_MANUAL", "MODULE",
                        self.module_name,
                        self.cmd_FEED_MANUAL)
        self.gcode.register_mux_command("FEED_RUNOUT_EVENT_HANDLE", "MODULE",
                        self.module_name,
                        self.cmd_FEED_RUNOUT_EVENT_HANDLE)
        self.gcode.register_mux_command("FEED_RUNOUT_REFILL_RESUME", "MODULE",
                        self.module_name,
                        self.cmd_FEED_RUNOUT_REFILL_RESUME)

        self.printer.register_event_handler("klippy:ready", self._ready)
        self.printer.register_event_handler("ace:gate_changed", self._ace_gate_changed)
        self.printer.register_event_handler("filament_switch_sensor:runout", self._runout_evt_handle)
        self._check_init_state_timer = self.reactor.register_timer(self._check_init_state_timer_handler)

        self._feed_preload_counts = int(preload_length / FEED_WHEEL_CIRCUMFERENCE * 2)
        self._feed_load_counts_max = int(FEED_LOAD_LENGTH_MAX / FEED_WHEEL_CIRCUMFERENCE * 2)

        self.motor_speed_slow_switching = FEED_MOTOR_SPEED_SLOW_SWITCHING
        self.motor_speed_preload = FEED_MOTOR_SPEED_PRELOAD
        self.motor_speed_load = FEED_MOTOR_SPEED_LOAD
        self.motor_speed_extrude = FEED_MOTOR_SPEED_EXTRUDE
        self.motor_speed_hang_neutral_a = FEED_MOTOR_SPEED_HANG_NEUTRAL_A
        self.motor_speed_hang_neutral_b = FEED_MOTOR_SPEED_HANG_NEUTRAL_B
        self.motor_hang_neutral_time = FEED_MOTOR_HANG_NEUTRAL_TIME

        self._last_print_time = 0
        for ch in range(FEED_CHANNEL_NUMS):
            self.channel_state[ch] = FEED_STA_INITED

    def _ready(self):
        self.toolhead = self.printer.lookup_object('toolhead')
        self.gcode_move = self.printer.lookup_object('gcode_move')
        self.ace = self.printer.lookup_object('ace', None)
        for port in self._port:
            port.add_ace(self.ace)
        self.exception_manager = self.printer.lookup_object('exception_manager', None)
        self.reactor.update_timer(self._check_init_state_timer,
                                  self.reactor.monotonic() + 2 * FEED_PORT_ADC_REPORT_TIME)

    def _ace_gate_changed(self, index, present):
        if self.ace is None or index not in self.filament_ch:
            return
        ch = self.filament_ch.index(index)
        if present:
            self._ace_runout_refill(ch)
        if (self.channel_active is not None or not self.module_exist[ch]
                or not self.config['auto_mode'][ch]
                or self.channel_state[ch] not in (
                    FEED_STA_NONE, FEED_STA_INITED, FEED_STA_WAIT_INSERT,
                    FEED_STA_PRELOAD_FINISH, FEED_STA_LOAD_FINISH, FEED_STA_UNLOAD_FINISH)):
            return
        # UI readiness only: never invoke the stock port event or move motors.
        sensor = self.runout_sensor[ch]
        if sensor is None or sensor.get_status(self.reactor.monotonic())['filament_detected']:
            return
        self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH if present else FEED_STA_WAIT_INSERT, True)

    # --- Runout continuation -------------------------------------------------
    # The U1 head sensor pauses the print. This module then empties the nozzle,
    # switches the nozzle heaters off and resumes after the same ACE slot is
    # refilled. The stock pause/resume macros keep ownership of all motion.

    def _ace_runout_paused_for(self, extruder_index):
        print_stats = self.printer.lookup_object('print_stats', None)
        macro = self.printer.lookup_object('gcode_macro INNER_RESUME', None)
        if print_stats is None or macro is None or print_stats.state != 'paused':
            return False
        variables = getattr(macro, 'variables', {})
        try:
            return (int(variables.get('is_runout', 0)) == 1
                    and int(variables.get('last_extruder_index', -1)) == extruder_index)
        except (TypeError, ValueError):
            return False

    def _ace_runout_still_waiting(self, ch, wait):
        if self._ace_runout_wait.get(ch) is not wait:
            return False
        if not self._ace_runout_paused_for(wait['extruder']):
            # Resumed, replenished from another head, or cancelled elsewhere.
            self._ace_runout_wait.pop(ch, None)
            return False
        return True

    def _ace_runout_flush(self, ch, extruder_index):
        ace = self.ace
        length = getattr(ace, 'runout_flush_length', 0)
        if length <= 0:
            return
        macro = self.printer.lookup_object('gcode_macro INNER_RESUME', None)
        try:
            temp = float(getattr(macro, 'variables', {}).get('last_extruder_temp', 0))
        except (TypeError, ValueError):
            temp = 0.
        active = self.toolhead.get_extruder()
        homed = self.toolhead.get_status(self.reactor.monotonic())['homed_axes']
        if (temp < 170 or getattr(active, 'extruder_index', None) != extruder_index
                or not all(axis in homed for axis in 'xyz')):
            self.gcode.respond_info('Runout flush skipped: nozzle e%d is not ready' % extruder_index)
            return
        speed = getattr(ace, 'runout_flush_speed', 150)
        lines = ['M109 S%d T%d A0' % (int(temp), extruder_index), 'M83']
        remaining = float(length)
        while remaining > 0:
            step = min(10., remaining)
            lines.append('G1 E%.2f F%d' % (step, speed))
            remaining -= step
        lines.append('M400')
        entangle = self.printer.lookup_object(
                'filament_entangle_detect e%d_filament' % extruder_index, None)
        try:
            if entangle is not None:
                entangle.skip_entangle_check(True)
            self.gcode.run_script_from_command('\n'.join(lines))
        finally:
            if entangle is not None:
                entangle.skip_entangle_check(False)

    def _ace_runout_begin(self, ch):
        ace = self.ace
        extruder_index = self.filament_ch[ch]
        self._ace_runout_wait.pop(ch, None)
        if not self._ace_runout_paused_for(extruder_index):
            return
        try:
            ace._stop_feed_assist_only()
        except Exception as exc:
            ace.log_error('ACE runout assist cleanup failed: %s' % (exc,))
        try:
            self._ace_runout_flush(ch, extruder_index)
        except Exception as exc:
            logging.exception('[feed] runout flush failed')
            ace.log_error('Runout flush failed: %s' % (exc,))
        wait = {'extruder': extruder_index, 'worker': False}
        self._ace_runout_wait[ch] = wait
        if ace.gate_status[extruder_index] == 1:
            # Already refilled behind the old tail: keep the nozzle hot.
            self.gcode.respond_info(
                'Filament ran out at U1 head e%d; ACE slot %d already holds new filament'
                % (extruder_index, extruder_index))
            self._ace_runout_refill(ch)
            return
        if getattr(ace, 'runout_heaters_off', True):
            for i in range(4):
                name = 'extruder' if i == 0 else 'extruder%d' % i
                if self.printer.lookup_object(name, None) is not None:
                    self.gcode.run_script_from_command('M104 S0 T%d A0' % i)
        self.gcode.respond_info(
            'Filament ran out at U1 head e%d; nozzle heaters are off. '
            'Insert new filament into ACE slot %d to continue'
            % (extruder_index, extruder_index))

    def _ace_runout_refill(self, ch):
        wait = self._ace_runout_wait.get(ch)
        if (wait is None or wait['worker'] or self.ace is None
                or not getattr(self.ace, 'runout_auto_resume', True)):
            return
        wait['worker'] = True
        self.reactor.register_async_callback(
            (lambda et, c=self._ace_runout_refill_worker, ch=ch, wait=wait: c(ch, wait)))

    def _ace_runout_refill_worker(self, ch, wait):
        ace = self.ace
        index = wait['extruder']
        try:
            start = self.reactor.monotonic()
            settle = getattr(ace, 'runout_resume_settle', 8)
            deadline = start + settle + FEED_ACE_REFILL_READY_TIMEOUT
            while True:
                if not self._ace_runout_still_waiting(ch, wait):
                    return
                if ace.gate_status[index] != 1:
                    # Pulled out again; the next insertion starts a new attempt.
                    return
                now = self.reactor.monotonic()
                if (now - start >= settle and self.channel_active is None
                        and ace.refill_ready(index)):
                    break
                if now >= deadline:
                    ace.log_error('ACE slot %d is not ready after refill; select Resume on the U1' % index)
                    return
                self.reactor.pause(now + 0.5)
            wait['ready'] = True
            self.gcode.run_script('FEED_RUNOUT_REFILL_RESUME MODULE=%s CHANNEL=%d'
                                  % (self.module_name, ch))
        except Exception:
            logging.exception('[feed] channel[%d]: runout refill resume error', ch)
        finally:
            wait['worker'] = False
            wait.pop('ready', None)

    def _ace_runout_material_changed(self, extruder_index):
        config = self.printer.lookup_object('print_task_config', None)
        try:
            before = config.filament_info_backup['filament_type'][extruder_index]
            after = config.print_task_config['filament_type'][extruder_index]
        except Exception:
            return None
        if before in ('', 'NONE') or after in ('', 'NONE') or before == after:
            return None
        return (before, after)

    def cmd_FEED_RUNOUT_REFILL_RESUME(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))
        # Runs under the G-code mutex, so a stock resume cannot overlap it.
        wait = self._ace_runout_wait.get(channel)
        if (self.ace is None or wait is None or not wait.get('ready')
                or not self._ace_runout_still_waiting(channel, wait)):
            return
        index = wait['extruder']
        if self.ace.gate_status[index] != 1:
            return
        self._ace_runout_wait.pop(channel, None)
        changed = self._ace_runout_material_changed(index)
        if changed is not None:
            gcmd.respond_info(
                'ACE slot %d now holds %s instead of %s; print stays paused. '
                'Select Resume on the U1 to continue with it' % (index, changed[1], changed[0]))
            return
        gcmd.respond_info('ACE slot %d refilled; loading and resuming the print' % index)
        self.gcode.run_script_from_command('RESUME')

    def _ace_head_present(self, ch):
        sensor = self.runout_sensor[ch]
        if sensor is None:
            raise ValueError('U1 head filament sensor is missing')
        state = sensor.get_status(self.reactor.monotonic())
        if not state.get('enabled', False):
            raise ValueError('U1 head filament sensor is disabled')
        return bool(state['filament_detected'])

    def _ace_check_load(self, ch, token):
        ace = self.ace
        if (token is None or getattr(ace, '_u1_load_owner', None) is not token
                or token['owner'] is not self or token['channel'] != ch
                or token.get('cancelled', False)
                or not ace._connected or ace._shutting_down
                or ace._connected_at != token['connection']):
            self.channel_error[ch] = FEED_ERR_TIMEOUT
            self.exception_code[ch] = 34
            raise ValueError('ACE loading interrupted; no automatic resend')
        if ace._gate_epochs[token['index']] != token['gate_epoch']:
            if self._port[ch].get_filament_detected():
                self.channel_error[ch] = FEED_ERR_TIMEOUT
                self.exception_code[ch] = 34
            else:
                self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                self.exception_code[ch] = 33
            raise ValueError('ACE insertion changed while loading; no automatic resend')

    def _ace_wait_load_ready(self, ch, token, timeout):
        deadline = self.reactor.monotonic() + timeout
        while True:
            self._ace_check_load(ch, token)
            if not self._port[ch].get_filament_detected():
                self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                self.exception_code[ch] = 33
                raise ValueError('ACE inlet is empty')
            self._ace_head_present(ch)  # Also require an enabled, working sensor.
            if self.ace.is_ace_ready() and not self.ace._control_inflight:
                return
            if self.reactor.monotonic() >= deadline:
                self.channel_error[ch] = FEED_ERR_TIMEOUT
                self.exception_code[ch] = 34
                raise ValueError('ACE ready wait timed out')
            self.reactor.pause(min(deadline, self.reactor.monotonic() + 0.105))

    def _ace_claim_load(self, ch, kind='load'):
        ace = self.ace
        if getattr(ace, '_u1_load_owner', None) is not None:
            self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
            raise ValueError('Another U1 channel is already using ACE')
        index = self.filament_ch[ch]
        token = {'owner': self, 'channel': ch, 'index': index, 'kind': kind,
                 'connection': ace._connected_at,
                 'gate_epoch': ace._gate_epochs[index], 'allow_assist': False}
        ace._u1_load_owner = token
        return token

    def _ace_mark_unloaded(self, ch, connection, gate_epoch, advance_upper_mm=0):
        ace = self.ace
        index = self.filament_ch[ch]
        if self._ace_head_present(ch):
            self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
            raise ValueError('U1 head still detects filament after ACE retract; unload position not confirmed')
        if (ace._connected and ace._connected_at == connection
                and ace._gate_epochs[index] == gate_epoch
                and self._port[ch].get_filament_detected()):
            return ace.mark_unloaded(index, connection, gate_epoch,
                                     advance_upper_mm=advance_upper_mm)
        return False

    def _ace_check_unload(self, ch, token, require_head_empty=False):
        self._ace_check_load(ch, token)
        if token.get('kind') != 'unload':
            self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
            raise ValueError('ACE unload ownership changed; no automatic resend')
        if not self._port[ch].get_filament_detected():
            self.channel_error[ch] = FEED_ERR_NO_FILAMENT
            self.exception_code[ch] = 33
            raise ValueError('ACE inlet became empty while unloading')
        if require_head_empty and self._ace_head_present(ch):
            self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
            raise ValueError('U1 head detects filament after ACE retract; unload position not confirmed')

    def _ace_complete_unload(self, ch, token):
        # Keep one owner through the normal retract, optional bounded forward
        # take-up and origin publication. No stage is automatically retried.
        ace = self.ace
        index = self.filament_ch[ch]
        self._ace_check_unload(ch, token)
        ace._stop_feed_assist_only()
        self._ace_check_unload(ch, token)
        ace.retract_fil(index)

        def poll():
            self._ace_check_unload(ch, token, require_head_empty=True)

        poll()
        advance = ace.forward_takeup(index, token['connection'], token['gate_epoch'],
                                     _poll=poll, token=token)
        poll()
        if not self._ace_mark_unloaded(ch, token['connection'], token['gate_epoch'],
                                       advance_upper_mm=advance):
            self.channel_error[ch] = FEED_ERR_TIMEOUT
            self.exception_code[ch] = 34
            raise ValueError('ACE unload completion could not be confirmed; no automatic resend')

    def _ace_feed_to_sensor(self, ch):
        # A verified insertion/unload origin permits one bounded fast segment.
        # The U1 head sensor is always the endpoint, including during the ACK.
        ace = self.ace
        index = self.filament_ch[ch]
        if self._ace_head_present(ch):
            return
        token = getattr(ace, '_u1_load_owner', None)
        self._ace_check_load(ch, token)
        started = False
        stop_confirmed = False
        primary_error = None
        arrived = RuntimeError('ACE filament reached the U1 head sensor')
        deadline = None
        track_busy = False
        saw_busy = False

        def poll():
            nonlocal saw_busy
            self._ace_check_load(ch, token)
            if not self._port[ch].get_filament_detected():
                self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                self.exception_code[ch] = 33
                raise ValueError('ACE inlet became empty while loading')
            if self._ace_head_present(ch):
                raise arrived
            if track_busy:
                status = ace.get_status()
                if status['status_fresh'] and status['status'] == 'busy':
                    saw_busy = True
            if self.reactor.monotonic() >= deadline:
                self.channel_error[ch] = FEED_ERR_TIMEOUT
                self.exception_code[ch] = 34
                raise ValueError('ACE sensor seek timed out; no automatic resend')

        try:
            ace._stop_feed_assist_only()
            self._ace_wait_load_ready(ch, token, ace.SENSOR_LOAD_WAIT_TIMEOUT)
            if self._ace_head_present(ch):
                return
            # Recheck and consume only after NFC and tool selection have settled.
            self._ace_check_load(ch, token)
            origin = ace.take_fast_origin(index)
            fast_length = 0
            if origin is not None:
                # Budget the complete forward command conservatively; the
                # firmware's reverse pre-step is not a position measurement.
                if not isinstance(origin, dict):
                    raise ValueError('ACE load origin lacks a verified advance budget')
                advance = origin.get('advance_upper_mm', 0)
                if (not isinstance(advance, (int, float)) or isinstance(advance, bool)
                        or not 0 <= advance <= ace.FAST_LOAD_LENGTH):
                    raise ValueError('ACE load origin has an invalid advance budget')
                fast_length = max(0, ace.FAST_LOAD_LENGTH - advance)
            deadline = (self.reactor.monotonic() +
                        ace.SENSOR_LOAD_MAX_LENGTH / ace.SENSOR_LOAD_SPEED + ace.READY_TIMEOUT)
            if fast_length > 0:
                stages = ((fast_length, ace.FAST_LOAD_SPEED),
                          (ace.SENSOR_LOAD_MAX_LENGTH - fast_length,
                           ace.SENSOR_LOAD_SPEED))
            else:
                stages = ((ace.SENSOR_LOAD_MAX_LENGTH, ace.SENSOR_LOAD_SPEED),)
            for stage_index, (length, speed) in enumerate(stages):
                requires_busy = fast_length > 0 and stage_index == 0
                track_busy = False
                saw_busy = False
                poll()
                started = True
                track_busy = requires_busy
                ace._feed(index, length, speed, 0, _poll=poll, _owner_token=token)
                while True:
                    poll()
                    # A queued fast move may ACK while the device still reports
                    # ready. Only a fresh busy-to-ready transition completes it.
                    if (ace.is_ace_ready() and not ace._control_inflight
                            and (not requires_busy or saw_busy)):
                        break
                    self.reactor.pause(min(deadline, self.reactor.monotonic() + 0.105))
            self.channel_error[ch] = FEED_ERR_TIMEOUT
            self.exception_code[ch] = 34
            raise ValueError('ACE maximum seek distance reached without the U1 sensor')
        except Exception as exc:
            stop_confirmed = bool(getattr(exc, '_ace_feed_stop_confirmed', False))
            if exc is arrived:
                self.channel_error[ch] = FEED_OK
                return
            primary_error = exc
            raise
        finally:
            if (started and ace._connected and ace._connected_at == token['connection']
                    and getattr(ace, '_u1_load_owner', None) is token):
                original_error = self.channel_error[ch]
                original_code = self.exception_code[ch]
                try:
                    if not stop_confirmed:
                        ace._stop_feeding(index)
                    ace.wait_ace_ready(timeout=ace.SENSOR_LOAD_FINISH_TIMEOUT)
                    self._ace_check_load(ch, token)
                    if (self.channel_error[ch] == FEED_OK
                            and (not self._ace_head_present(ch)
                                 or not self._port[ch].get_filament_detected())):
                        self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                        self.exception_code[ch] = 33
                except Exception as cleanup:
                    if primary_error is not None or original_error != FEED_OK:
                        self.channel_error[ch] = original_error
                        self.exception_code[ch] = original_code
                        ace.log_error('ACE final-feed cleanup also failed: %s' % (cleanup,))
                    else:
                        raise

    def _runout_evt_handle(self, extruder, present):
        if present == True:
            return

        for ch in range(FEED_CHANNEL_NUMS):
            if extruder == self.filament_ch[ch]:
                if self.channel_state[ch] in [FEED_STA_LOAD_FEEDING, FEED_STA_LOAD_EXTRUDING, FEED_STA_LOAD_FLUSHING]:
                    return
                self.reactor.register_async_callback(
                    (lambda et, c=self._do_feed, ch=ch, action=FEED_ACT_FILAMENT_RUNOUT: c(ch, action)))
                break

    def _check_init_state_timer_handler(self, eventtime):
        self.reactor.unregister_timer(self._check_init_state_timer)

        for ch in range(FEED_CHANNEL_NUMS):
            if self._port[ch].get_adc_value() < FEED_PORT_ADC_VAL_MODULE_EXIST or self.ace is not None:
                self.module_exist[ch] = True
            else:
                self.module_exist[ch] = False

            if self.config['auto_mode'][ch] == True and self.module_exist[ch] == True:
                if self.filament_detect.is_startup_stay() == False:
                    self.printer.send_event("filament_feed:port", self.filament_ch[ch],
                                            self._port[ch].get_filament_detected())
                if self._port[ch].get_filament_detected() == False:
                    self._set_channel_state(ch, FEED_STA_WAIT_INSERT)
                else:
                    if self.config['load_finish'][ch] == True:
                        self._set_channel_state(ch, FEED_STA_LOAD_FINISH)
                    else:
                        self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH)
            else:
                if self.config['load_finish'][ch] == True:
                    self._set_channel_state(ch, FEED_STA_LOAD_FINISH)

        return self.reactor.NEVER

    def _set_channel_state(self, channel, state, save=False):
        systime = self.reactor.monotonic()
        systime += FEED_MIN_TIME
        print_time = self.light[channel].get_mcu().estimated_print_time(systime)
        if print_time - self._last_print_time < FEED_MIN_TIME:
            print_time = self._last_print_time + FEED_MIN_TIME

        if self.config['auto_mode'][channel] == False:
            self.light[channel].set_light_state(print_time, FEED_STA_NONE)
        else:
            self.light[channel].set_light_state(print_time, state)
        self.channel_state[channel] = state
        self._last_print_time = print_time

        if state not in [FEED_STA_INITED, FEED_STA_WAIT_INSERT, FEED_STA_TEST] and \
                not state.startswith('preload_'):
            self.channel_action_state[channel] = state

        if save == True:
            if state == FEED_STA_LOAD_FINISH:
                self.config['load_finish'][channel] = True
            else:
                self.config['load_finish'][channel] = False
            if not self.printer.update_snapmaker_config_file(self.config_path, self.config, FEED_DEFAULT_CONFIG):
                logging.error("[feed] save config failed!")

    def _set_light_state(self, channel, state):
        systime = self.reactor.monotonic()
        systime += FEED_MIN_TIME
        print_time = self.light[channel].get_mcu().estimated_print_time(systime)
        if print_time - self._last_print_time < FEED_MIN_TIME:
            print_time = self._last_print_time + FEED_MIN_TIME

        self.light[channel].set_light_state(print_time, state)
        self._last_print_time = print_time

    def _port_ch1_event_handler(self, detected):
        self._port_event_handler(detected, FEED_CHANNEL_1)

    def _port_ch2_event_handler(self, detected):
        self._port_event_handler(detected, FEED_CHANNEL_2)

    def _port_event_handler(self, detected, channel):
        if self.ace is not None:
            # Native U1 ADC edges must not launch the stock automatic preloader.
            # ACE gate and NFC are maintained by the ACE heartbeat instead.
            return
        if self.debug_mode != 0:
            logging.info("[feed] port event: channel=%d, detected=%d" % (channel, detected))
            runout_sensor_status = self.runout_sensor[channel].get_status(0)
            feed_status = self.get_status()
            logging.info("[feed] port event: channel=%d, runout_sensor_status=%s, feed_status=%s" % (channel, str(runout_sensor_status), str(feed_status)))


        if self.config['auto_mode'][channel] == False or \
                self.module_exist[channel] == False:
            return

        self.printer.send_event("filament_feed:port", self.filament_ch[channel], detected)

        if self.runout_sensor[channel] is None or \
                self.runout_sensor[channel].get_status(0)['enabled'] == False:
            return

        if self.manual_feeding[channel]:
            return

        if detected:
            if self.channel_state[channel] == FEED_STA_PRELOAD_PREPARE:
                self._set_light_state(channel, FEED_STA_PRELOAD_PREPARE)
                return
            else:
                self._set_channel_state(channel, FEED_STA_PRELOAD_PREPARE)
                self.reactor.register_async_callback(
                    (lambda et, c=self._do_feed, ch=channel, action=FEED_ACT_PRELOAD: c(ch, action)))
        else:
            if self.channel_active != channel:
                self._set_light_state(channel, FEED_STA_WAIT_INSERT)
            self.reactor.register_async_callback(
                (lambda et, c=self._do_feed, ch=channel, action=FEED_ACT_REMOVE_FILAMENT: c(ch, action)))

    def _check_homing_xy(self):
        curtime = self.reactor.monotonic()
        homed_axes_list = self.toolhead.get_status(curtime)['homed_axes']
        return ('x' in homed_axes_list and 'y' in homed_axes_list)

    def _get_filament_temp(self, channel):
        print_task_config = self.printer.lookup_object('print_task_config', None)
        filament_parameters = self.printer.lookup_object('filament_parameters', None)
        extruder_obj = self.printer.lookup_object("extruder", None)
        if self.filament_ch[channel] != 0:
            extruder_obj = self.printer.lookup_object(f"extruder{self.filament_ch[channel]}", None)
        if print_task_config is None or filament_parameters is None or extruder_obj is None:
            return FEED_FILAMENT_TEMP_DEFAULT

        status = print_task_config.get_status()
        return filament_parameters.get_load_temp(
                status['filament_vendor'][self.filament_ch[channel]],
                status['filament_type'][self.filament_ch[channel]],
                status['filament_sub_type'][self.filament_ch[channel]],
                extruder_obj.nozzle_diameter,
                extruder_obj.nozzle_volume_type)
    def _get_filament_soft(self, channel):
        print_task_config = self.printer.lookup_object('print_task_config', None)
        filament_parameters = self.printer.lookup_object('filament_parameters', None)
        extruder_obj = self.printer.lookup_object("extruder", None)
        if self.filament_ch[channel] != 0:
            extruder_obj = self.printer.lookup_object(f"extruder{self.filament_ch[channel]}", None)
        if print_task_config is None or filament_parameters is None or extruder_obj is None:
            return False

        status = print_task_config.get_status()
        return filament_parameters.get_is_soft(
                status['filament_vendor'][self.filament_ch[channel]],
                status['filament_type'][self.filament_ch[channel]],
                status['filament_sub_type'][self.filament_ch[channel]],
                extruder_obj.nozzle_diameter,
                extruder_obj.nozzle_volume_type)

    def _hang_neutral(self, channel):
        self.reactor.pause(self.reactor.monotonic() + 0.105)
        motor_cnt_1 = self.motor_tachometer.get_counts()
        for retry in range(2):
            if channel == FEED_CHANNEL_1:
                self.motor.run_one_cycle(FEED_MOTOR_DIR_B,
                        self.motor_speed_hang_neutral_b,
                        self.motor_hang_neutral_time)
            else:
                self.motor.run_one_cycle(FEED_MOTOR_DIR_A,
                                        self.motor_speed_hang_neutral_a,
                                        self.motor_hang_neutral_time)
            self.reactor.pause(self.reactor.monotonic() + 0.105)
            motor_cnt_2 = self.motor_tachometer.get_counts()
            logging.info("[feed] extruder[%d] hanging neutral, try: %d, cnt1:%d, cnt2: %d\r\n",
                         self.filament_ch[channel], retry, motor_cnt_1, motor_cnt_2)
            if motor_cnt_2 - motor_cnt_1 > 5:
                break

    def _put_into_drive(self, channel):
        logging.info("[feed] extruder[%d] putting into drive", self.filament_ch[channel])
        if channel == FEED_CHANNEL_1:
            self.motor.run_one_cycle(FEED_MOTOR_DIR_A,
                                     self.motor_speed_hang_neutral_a,
                                     self.motor_hang_neutral_time)
        else:
            self.motor.run_one_cycle(FEED_MOTOR_DIR_B,
                                     self.motor_speed_hang_neutral_b,
                                     self.motor_hang_neutral_time)

    def _is_keep_raw_error_info(self, error=None):
        if error in [FEED_ERR_MOVE, FEED_ERR_MOVE_HOME,
                     FEED_ERR_MOVE_SWITCH, FEED_ERR_HEAT]:
            return True
        else:
            return False

    def _do_feed(self, ch, action=None, stage=None, auto_mode=None):
        if ch < 0 or ch >= FEED_CHANNEL_NUMS or action == None:
            logging.error("[feed] parameter error!")
            return

        if action == FEED_ACT_UPDATE_AUTO_MODE and auto_mode is None:
            logging.error("[feed] parameter error!")
            return

        if action in [FEED_ACT_PRELOAD, FEED_ACT_LOAD] and \
                (self.config['auto_mode'][ch] == False or self.module_exist[ch] == False):
            return

        if self.ace is not None and action == FEED_ACT_PRELOAD:
            return

        ace_load_token = None
        ace_unload_token = None
        ace_unload_connection = self.ace._connected_at if self.ace is not None else None
        ace_unload_gate_epoch = None
        ace_unload_guard = False

        wheel_cnt_a_1 = 0
        wheel_cnt_b_1 = 0
        motor_cnt_1 = 0
        wheel_cnt_a_2 = 0
        wheel_cnt_b_2 = 0
        motor_cnt_2 = 0

        if action == FEED_ACT_PRELOAD:
            wheel_cnt_a_1 = self.wheel[ch].get_counts()
            wheel_cnt_b_1 = self.wheel_2[ch].get_counts()

        while self.channel_active != None:
            self.reactor.pause(self.reactor.monotonic() + 0.1)
        self.channel_active = ch
        self.channel_error[ch] = FEED_OK
        self.exception_code[ch] = 0

        filament_feed_temp = self._get_filament_temp(ch)
        filament_soft = self._get_filament_soft(ch)

        motor_dir = FEED_MOTOR_DIR_A
        if ch == FEED_CHANNEL_2:
            motor_dir = FEED_MOTOR_DIR_B

        try:
            # update auto-mode
            if action == FEED_ACT_UPDATE_AUTO_MODE:
                self.config['auto_mode'][ch] = bool(auto_mode)
                if self.config['auto_mode'][ch] == True:
                    if self.module_exist[ch]:
                        if self._port[ch].get_filament_detected() == False:
                            self._set_channel_state(ch, FEED_STA_WAIT_INSERT, True)
                        else:
                            if self.channel_state[ch] != FEED_STA_LOAD_FINISH:
                                self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH, True)
                            else:
                                self._set_channel_state(ch, FEED_STA_LOAD_FINISH, True)
                    else:
                        if self.channel_state[ch] != FEED_STA_LOAD_FINISH:
                            self._set_channel_state(ch, FEED_STA_NONE, True)
                        else:
                            self._set_channel_state(ch, FEED_STA_LOAD_FINISH, True)
                else:
                    if self.channel_state[ch] != FEED_STA_LOAD_FINISH:
                        self._set_channel_state(ch, FEED_STA_NONE, True)
                    else:
                        self._set_channel_state(ch, FEED_STA_LOAD_FINISH, True)

            # remove filament
            elif action == FEED_ACT_REMOVE_FILAMENT:
                if self._port[ch].get_filament_detected() == False:
                    self._set_channel_state(ch, FEED_STA_WAIT_INSERT, True)
                else:
                    self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH, True)

            # filament runout
            elif action == FEED_ACT_FILAMENT_RUNOUT:
                if self._port[ch].get_filament_detected() == True:
                    self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH, True)
                else:
                    self._set_channel_state(ch, FEED_STA_WAIT_INSERT, True)

            # preload
            elif action == FEED_ACT_PRELOAD:
                has_put_into_drive = False
                try:
                    self.exception_code[ch] = 10
                    self.channel_error_state[ch] = FEED_STA_NONE
                    self._set_channel_state(ch, FEED_STA_PRELOAD_PREPARE, True)

                    if self._port[ch].get_filament_detected() == False:
                        self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                        self.exception_code[ch] = 13
                        raise

                    if self.runout_sensor[ch].get_status(0)['filament_detected']:
                        self.channel_error[ch] = FEED_ERR_RESIDUAL_FILAMENT
                        self.exception_code[ch] = 15
                        raise

                    self.reactor.pause(self.reactor.monotonic() + 1)

                    motor_cnt_1 = self.motor_tachometer.get_counts()
                    logging.info("[feed_preload] extruder[%d], start, wheel_cnt_a: %d, wheel_cnt_b: %d, motor_cnt: %d",
                                  self.filament_ch[ch], wheel_cnt_a_1, wheel_cnt_b_1, motor_cnt_1)

                    # feed
                    self._set_channel_state(ch, FEED_STA_PRELOAD_FEEDING)
                    systime_1 = self.reactor.monotonic()
                    self.motor.run(motor_dir, self.motor_speed_slow_switching)
                    has_put_into_drive = True
                    arrive_runout_sensor = False
                    logging.info("[feed] extruder[%d] putting into drive", self.filament_ch[ch])
                    self.reactor.pause(self.reactor.monotonic() + 0.5)

                    preload_duty = self.motor_speed_preload
                    if arrive_runout_sensor == False:
                        for i in range(3):
                            self.motor.run(motor_dir, preload_duty)
                            self.reactor.pause(self.reactor.monotonic() + 0.35)
                            arrive_runout_sensor = self.runout_sensor[ch].get_status(0)['filament_detected']
                            if arrive_runout_sensor == True or preload_duty >= 1.0:
                                break
                            preload_duty = min(1.0, preload_duty + 0.1)
                        if arrive_runout_sensor == False and preload_duty < 1.0:
                            self.motor.run(motor_dir, 1.0)
                            self.reactor.pause(self.reactor.monotonic() + 0.2)
                            arrive_runout_sensor = self.runout_sensor[ch].get_status(0)['filament_detected']
                    logging.info("[feed_preload] extruder[%d], duty:%f, ", self.filament_ch[ch], preload_duty)

                    motor_speed = 0
                    wheel_speed_a = 0
                    wheel_speed_b = 0
                    wheel_speed_err_max = FEED_PRELOAD_WHEEL_ERR_CNT_MAX
                    motor_speed_err_max = FEED_PRELOAD_MOTOR_ERR_CNT_MAX
                    if arrive_runout_sensor == False:
                        while 1:
                            wheel_cnt_a_2 = self.wheel[ch].get_counts()
                            wheel_cnt_b_2 = self.wheel_2[ch].get_counts()
                            systime_2 = self.reactor.monotonic()
                            motor_speed = self.motor_tachometer.get_rpm()
                            wheel_speed_a = self.wheel[ch].get_rpm()
                            wheel_speed_b = self.wheel_2[ch].get_rpm()
                            port_detect = self._port[ch].get_filament_detected()
                            runout_detect = self.runout_sensor[ch].get_status(0)['filament_detected']

                            # Please do not adjust the order arbitrarily
                            if runout_detect == True:
                                self.channel_error[ch] = FEED_OK
                                break
                            if port_detect == False:
                                self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                                self.exception_code[ch] = 13
                                break
                            if (wheel_cnt_a_2 - wheel_cnt_a_1) / self.wheel[ch].ppr > self._feed_preload_counts or \
                                    (wheel_cnt_b_2 - wheel_cnt_b_1) / self.wheel_2[ch].ppr > self._feed_preload_counts:
                                self.channel_error[ch] = FEED_OK
                                break
                            if motor_speed < FEED_PRELOAD_MOTOR_MIN_SPEED:
                                logging.info("[feed_preload] extruder[%d], motor speed error, motor_speed:%d",
                                             self.filament_ch[ch], motor_speed)
                                if motor_speed_err_max > 0:
                                    motor_speed_err_max -= 1
                                else:
                                    self.channel_error[ch] = FEED_ERR_MOTOR_SPEED
                                    self.exception_code[ch] = 11
                                    break
                            else:
                                motor_speed_err_max = FEED_PRELOAD_MOTOR_ERR_CNT_MAX
                            if wheel_speed_a * FEED_MOTOR_REDUCTION_R < motor_speed * (1 - FEED_MOTOR_SLIP_RATE) and \
                                wheel_speed_b * FEED_MOTOR_REDUCTION_R < motor_speed * (1 - FEED_MOTOR_SLIP_RATE):
                                logging.info("[feed_preload] extruder[%d], wheel speed error, wheel_speed_a:%d, wheel_speed_b:%d, motor_speed:%d",
                                             self.filament_ch[ch], wheel_speed_a, wheel_speed_b, motor_speed)
                                if wheel_speed_err_max > 0:
                                    wheel_speed_err_max -= 1
                                else:
                                    self.channel_error[ch] = FEED_ERR_WHEEL_SPEED
                                    self.exception_code[ch] = 12
                                    break
                            else:
                                wheel_speed_err_max = FEED_PRELOAD_WHEEL_ERR_CNT_MAX
                            if systime_2 - systime_1 > FEED_PRELOAD_TIMEOUT_TIME:
                                self.channel_error[ch] = FEED_ERR_TIMEOUT
                                self.exception_code[ch] = 14
                                break

                            self.reactor.pause(self.reactor.monotonic() + 0.05)

                    self.motor.run(FEED_MOTOR_DIR_IDLE, 0)
                    wheel_cnt_a_2 = self.wheel[ch].get_counts()
                    wheel_cnt_b_2 = self.wheel_2[ch].get_counts()
                    motor_cnt_2 = self.motor_tachometer.get_counts()

                    logging.info("[feed_preloading] extruder[%d], wheel, cnt_a_1:%d, cnt_b_1:%d, cnt_a_2:%d, cnt_b_2:%d, wheel_speed_a:%d, wheel_speed_b: %d, "
                                 "motor, motor_cnt_1:%d, motor_cnt_2:%d, motor_speed:%d",
                                 self.filament_ch[ch], wheel_cnt_a_1, wheel_cnt_b_1, wheel_cnt_a_2, wheel_cnt_b_2, wheel_speed_a, wheel_speed_b,
                                 motor_cnt_1, motor_cnt_2, motor_speed)
                    if self.channel_error[ch] != FEED_OK:
                        raise

                    self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH)

                except:
                    if self.channel_error[ch] == FEED_OK:
                        self.channel_error[ch] = FEED_ERR
                        self.exception_code[ch] = 10
                    self._set_channel_state(ch, FEED_STA_PRELOAD_FAIL)
                    self.channel_error_state[ch] = self.channel_state[ch]
                    if self.exception_manager is not None:
                        self.exception_manager.raise_exception_async(
                            id = self.exception_manager.list.MODULE_ID_FEEDING,
                            index = self.filament_ch[ch],
                            code = self.exception_code[ch],
                            message = "preload fail: %s" % (self.channel_error[ch]),
                            oneshot = 1,
                            level = 1)

                finally:
                    if has_put_into_drive:
                        self._hang_neutral(ch)

            # load
            elif action == FEED_ACT_LOAD:
                try:
                    # prepare
                    self.exception_code[ch] = 30
                    self.manual_feeding[ch] = False
                    self.channel_error_state[ch] = FEED_STA_NONE
                    is_last_preload_normal = bool(self.channel_state[ch] == FEED_STA_PRELOAD_FINISH)
                    self._set_channel_state(ch, FEED_STA_LOAD_PREPARE, True)

                    if self.ace is not None:
                        ace_load_token = self._ace_claim_load(ch)
                        self.ace._stop_feed_assist_only()
                        self._ace_wait_load_ready(ch, ace_load_token,
                                                  self.ace.SENSOR_LOAD_WAIT_TIMEOUT)
                        # NFC may have supplied a new material while waiting.
                        filament_feed_temp = self._get_filament_temp(ch)
                        filament_soft = self._get_filament_soft(ch)

                    if self._port[ch].get_filament_detected() == False:
                        self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                        self.exception_code[ch] = 33
                        raise ValueError('logic error!')

                    self.gcode.run_script_from_command("M104 S%d T%d A0\r\n" % (filament_feed_temp - 70, self.filament_ch[ch]))

                    # home
                    try:
                        self._set_channel_state(ch, FEED_STA_LOAD_HOMING)
                        if self._check_homing_xy() != True:
                            self.gcode.run_script_from_command("G28 X Y\r\n")
                            self.toolhead.wait_moves()
                    except:
                        self.channel_error[ch] = FEED_ERR_MOVE_HOME
                        raise

                    # switch extruder
                    try:
                        self._set_channel_state(ch, FEED_STA_LOAD_PICKING)
                        self.gcode.run_script_from_command("T%d A0\r\n" % (self.filament_ch[ch]))
                        self.toolhead.wait_moves()
                    except:
                        self.channel_error[ch] = FEED_ERR_MOVE_SWITCH
                        raise

                    if is_last_preload_normal:
                        self.gcode.run_script_from_command("M104 S%d\r\n" % (filament_feed_temp))
                    else:
                        self.gcode.run_script_from_command("M104 S%d\r\n" % (filament_feed_temp - 50))

                    # feed filament
                    self._set_channel_state(ch, FEED_STA_LOAD_FEEDING)
                    self._put_into_drive(ch)
                    self.toolhead.wait_moves()

                    # Please do not adjust the order arbitrarily
                    if self.runout_sensor[ch].get_status(0)['filament_detected'] == False:
                        # move to dest position
                        try:
                            self.toolhead.wait_moves()
                            self.gcode.run_script_from_command( \
                                f"G90\nG0 Y{self._feed_load_position_y} F18000\r\n")
                            self.gcode.run_script_from_command( \
                                f"G90\nG0 X{self._feed_load_position_x} F18000\r\n")
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE
                            raise

                        self.reactor.pause(self.reactor.monotonic() + 0.105)
                        wheel_cnt_a_0 = self.wheel[ch].get_counts()
                        wheel_cnt_b_0 = self.wheel_2[ch].get_counts()
                        systime_0 = self.reactor.monotonic()
                        duty = self.motor_speed_load
                        period = 0.09
                        motor_err_max_cnt = FEED_LOAD_MOTOR_ERR_CNT_MAX
                        wheel_err_max_cnt = FEED_LOAD_WHEEL_ERR_CNT_MAX
                        one_step_cnt = self.wheel[ch].ppr * 2.0 * 10.0 / FEED_WHEEL_CIRCUMFERENCE

                        if self.ace is not None:
                            self._ace_feed_to_sensor(ch)
                        else:
                            while 1:
                                wheel_cnt_a_1 = self.wheel[ch].get_counts()
                                wheel_cnt_b_1 = self.wheel_2[ch].get_counts()
                                motor_cnt_1 = self.motor_tachometer.get_counts()
                                self.motor.run_one_cycle(motor_dir, duty, period)
                                self.reactor.pause(self.reactor.monotonic() + 0.105)
                                systime_2 = self.reactor.monotonic()
                                motor_cnt_2 = self.motor_tachometer.get_counts()
                                wheel_cnt_a_2 = self.wheel[ch].get_counts()
                                wheel_cnt_b_2 = self.wheel_2[ch].get_counts()
                                port_detect = self._port[ch].get_filament_detected()
                                runout_detect = self.runout_sensor[ch].get_status(0)['filament_detected']
                                logging.info("[feed_loading] phase2: duty:%f, period:%f, "
                                             "wheel, cnt_a_0:%d, cnt_a_1:%d, cnt_a_2:%d, cnt_b_0:%d, cnt_b_1:%d, cnt_b_2:%d, cnterr:%d, "
                                             "motor, cnt_0:%d, cnt_1:%d, cnt_2:%d, cnterr:%d",
                                             duty, period,
                                             wheel_cnt_a_0, wheel_cnt_a_1, wheel_cnt_a_2, wheel_cnt_b_0, wheel_cnt_b_1, wheel_cnt_b_2, wheel_err_max_cnt,
                                             motor_cnt_1, motor_cnt_2, motor_cnt_2 - motor_cnt_1, motor_err_max_cnt)
                                if runout_detect == True:
                                    self.channel_error[ch] = FEED_OK
                                    break
                                if port_detect == False:
                                    self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                                    self.exception_code[ch] = 33
                                    break
                                if systime_2 - systime_0 > FEED_LOAD_TIMEOUT_TIME:
                                    self.channel_error[ch] = FEED_ERR_TIMEOUT
                                    self.exception_code[ch] = 34
                                    break
                                if (wheel_cnt_a_2 - wheel_cnt_a_0) / self.wheel[ch].ppr > self._feed_load_counts_max or \
                                        (wheel_cnt_b_2 - wheel_cnt_b_0) / self.wheel_2[ch].ppr > self._feed_load_counts_max:
                                    self.channel_error[ch] = FEED_ERR_DISTANCE
                                    self.exception_code[ch] = 35
                                    break
                                if wheel_cnt_a_2 - wheel_cnt_a_1 < 1 and wheel_cnt_b_2 - wheel_cnt_b_1 < 1:
                                    wheel_err_max_cnt -= 1
                                    if wheel_err_max_cnt <= 0:
                                        self.channel_error[ch] = FEED_ERR_WHEEL_SPEED
                                        self.exception_code[ch] = 32
                                        break
                                else:
                                    wheel_err_max_cnt = FEED_LOAD_WHEEL_ERR_CNT_MAX
                                if motor_cnt_2 - motor_cnt_1 < 1:
                                    motor_err_max_cnt -= 1
                                    if motor_err_max_cnt <= 0:
                                        self.channel_error[ch] = FEED_ERR_MOTOR_SPEED
                                        self.exception_code[ch] = 31
                                        break
                                else:
                                    motor_err_max_cnt = FEED_LOAD_MOTOR_ERR_CNT_MAX

                                if wheel_cnt_a_2 - wheel_cnt_a_1 > one_step_cnt or wheel_cnt_b_2 - wheel_cnt_b_1 > one_step_cnt:
                                    if duty > 0.7:
                                        duty = max(0.7, duty - 0.1)
                                    period = max(0.09, period - 0.01)
                                elif wheel_cnt_a_2 - wheel_cnt_a_1 < one_step_cnt and wheel_cnt_b_2 - wheel_cnt_b_1 < one_step_cnt:
                                    if duty < 1.0:
                                        duty = min(1.0, duty + 0.1)
                                    else:
                                        period = min(0.120, period + 0.01)

                        if self.channel_error[ch] != FEED_OK:
                            self._hang_neutral(ch)
                            raise ValueError('logic error!')

                    if self.ace is not None:
                        self._ace_check_load(ch, ace_load_token)
                        filament_feed_temp = self._get_filament_temp(ch)
                        filament_soft = self._get_filament_soft(ch)
                        ace_load_token['allow_assist'] = True
                        self.ace._enable_feed_assist(self.filament_ch[ch])
                    self.gcode.run_script_from_command("M104 S%d\r\n" % (filament_feed_temp))
                    try:
                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("MOVE_TO_DISCARD_FILAMENT_POSITION\r\n")
                        self.toolhead.wait_moves()
                    except:
                        self.channel_error[ch] = FEED_ERR_MOVE
                        raise

                    # heating
                    self._set_channel_state(ch, FEED_STA_LOAD_HEATING)
                    try:
                        self.gcode.run_script_from_command("M109 S%d\r\n" % (filament_feed_temp))
                    except:
                        self.channel_error[ch] = FEED_ERR_HEAT
                        raise

                    # extruding
                    self.exception_code[ch] = 50
                    self._set_channel_state(ch, FEED_STA_LOAD_EXTRUDING)
                    inductance_coil = None
                    try:
                        inductance_coil = self.toolhead.get_extruder().binding_probe.sensor
                    except:
                        logging.info("[feed_loading] inductance_coil not found")
                        inductance_coil = None

                    extruded = False
                    try:
                        duty = 0.8
                        period = 0.100
                        self.gcode.run_script_from_command("M83\r\n")
                        for retry in range(self._feed_load_extrude_max_times):
                            self.toolhead.wait_moves()
                            self.reactor.pause(self.reactor.monotonic() + 0.105)
                            wheel_cnt_a_1 = self.wheel[ch].get_counts()
                            wheel_cnt_b_1 = self.wheel_2[ch].get_counts()
                            coil_freq_start = 0
                            coil_freq_end_min = 0
                            coil_freq_end_max = 0
                            coil_freq_threshold = 1500
                            coil_freq_sample_times = 5
                            coil_freq_time_interval = 0.1
                            extrude_length = 20
                            extrude_speed = 400
                            retry_extrude_times = 2
                            if filament_soft == True:
                                extrude_length = 30
                                extrude_speed = 200
                                coil_freq_time_interval = 1.0
                                coil_freq_sample_times = 8
                                coil_freq_threshold = self.coil_freq_threshold_soft
                                retry_extrude_times = 3
                            else:
                                extrude_length = 20
                                extrude_speed = 400
                                coil_freq_time_interval = 0.5
                                coil_freq_sample_times = 5
                                coil_freq_threshold = self.coil_freq_threshold_hard
                                retry_extrude_times = 2

                            for retry_extrude in range(retry_extrude_times):
                                if inductance_coil is not None:
                                    coil_freq_start = inductance_coil.get_coil_freq()
                                    coil_freq_end_min = coil_freq_end_max = coil_freq_start
                                self.gcode.run_script_from_command(f"G1 E{extrude_length} F{extrude_speed}\r\n")
                                self.reactor.pause(self.reactor.monotonic() + 0.5)
                                if inductance_coil is not None:
                                    for i in range(coil_freq_sample_times):
                                        tmp_coil_frep = inductance_coil.get_coil_freq()
                                        if tmp_coil_frep > coil_freq_end_max:
                                            coil_freq_end_max = tmp_coil_frep
                                        elif tmp_coil_frep < coil_freq_end_min:
                                            coil_freq_end_min = tmp_coil_frep
                                        self.reactor.pause(self.reactor.monotonic() + coil_freq_time_interval)
                                self.toolhead.wait_moves()
                                self.reactor.pause(self.reactor.monotonic() + 0.105)
                                wheel_cnt_a_2 = self.wheel[ch].get_counts()
                                wheel_cnt_b_2 = self.wheel_2[ch].get_counts()
                                logging.info("[feed_loading] phase3: extrude[%d] retry:%d, retry_extrude:%d, "
                                             "coil_freq_start:%d, coil_freq_end_min:%d, coil_freq_end_max:%d, coil_freq_delta:%d",
                                                self.filament_ch[ch], retry, retry_extrude, coil_freq_start,
                                                coil_freq_end_min, coil_freq_end_max, coil_freq_end_max - coil_freq_end_min)
                                logging.info("[feed_loading] phase3: wheel, cnt_a_1:%d, cnt_a_2:%d, cnt_b_1:%d, cnt_b_2:%d",
                                         wheel_cnt_a_1, wheel_cnt_a_2, wheel_cnt_b_1, wheel_cnt_b_2)
                                if self.check_wheel_data != 0 and self.check_coil_freq == 0:
                                    if wheel_cnt_a_2 - wheel_cnt_a_1 >= 2 or wheel_cnt_b_2 - wheel_cnt_b_1 >= 2:
                                        extruded = True
                                        break
                                elif self.check_wheel_data == 0 and self.check_coil_freq != 0:
                                    if retry > 0 and inductance_coil is not None:
                                        if abs(coil_freq_end_min - coil_freq_start) >= coil_freq_threshold or \
                                                abs(coil_freq_end_max - coil_freq_start) >= coil_freq_threshold:
                                            extruded = True
                                            break
                                else:
                                    if wheel_cnt_a_2 - wheel_cnt_a_1 >= 2 or wheel_cnt_b_2 - wheel_cnt_b_1 >= 2:
                                        extruded = True
                                        break
                                    if retry > 0 and inductance_coil is not None:
                                        if abs(coil_freq_end_min - coil_freq_start) >= coil_freq_threshold or \
                                                abs(coil_freq_end_max - coil_freq_start) >= coil_freq_threshold:
                                            extruded = True
                                            break

                            if extruded == True:
                                break

                            self.gcode.run_script_from_command("ROUGHLY_CLEAN_NOZZLE_WITH_DISCARD\r\n")
                            self.toolhead.wait_moves()

                            if filament_soft:
                                self.gcode.run_script_from_command("G1 E50 F200\r\n")
                            else:
                                self.gcode.run_script_from_command("G1 E40 F480\r\n")
                            self.toolhead.get_last_move_time()
                            self.reactor.pause(self.reactor.monotonic() + 0.7)

                            if retry < 5:
                                duty = max(1.0, duty + 0.05)
                            else:
                                period = max(0.12, period + 0.01)
                            self.motor.run_one_cycle(motor_dir, duty, period)
                            self.toolhead.wait_moves()
                            logging.info(f"[feed_loading] phase3: retry:{retry}, duty:{duty}, period:{period}")
                    except Exception as e:
                        self.channel_error[ch] = FEED_ERR_MOVE_EXTRUDE
                        self.exception_code[ch] = 51
                        logging.error("[feed_loading] phase3: except rawinfo: %s", str(e))
                        raise ValueError('logic error!')
                    finally:
                        self._hang_neutral(ch)

                    if extruded == False:
                        self.channel_error[ch] = FEED_ERR_MOVE_EXTRUDE
                        self.exception_code[ch] = 51
                        raise ValueError('logic error!')

                    # flush filaments
                    self._set_channel_state(ch, FEED_STA_LOAD_FLUSHING)
                    try:
                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("INNER_FLUSH_FILAMENT TEMP=%d SOFT=%d NOZZLE_DIAMETER=%f\r\n" %
                                            (filament_feed_temp, int(filament_soft), self.toolhead.get_extruder().nozzle_diameter))
                        self.toolhead.wait_moves()
                    except:
                        self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                        raise ValueError('custom gcode error!')

                    # not need!
                    # if self._port[ch].get_filament_detected() == False:
                    #     self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                    #     raise

                    self.channel_error[ch] = FEED_OK
                    self._set_channel_state(ch, FEED_STA_LOAD_FINISH, True)

                except:
                    self.toolhead.wait_moves()
                    self.channel_error_state[ch] = self.channel_state[ch]
                    if self.channel_error[ch] == FEED_OK:
                        self.channel_error[ch] = FEED_ERR
                    self._set_channel_state(ch, FEED_STA_LOAD_FAIL)
                    raise

                finally:
                    self.gcode.run_script_from_command("M107\r\n")
                    self.gcode.run_script_from_command("M104 S0\r\n")

            # unload
            elif action == FEED_ACT_UNLOAD:
                if self.ace is not None:
                    if stage != FEED_UNLOAD_STAGE_CANCEL:
                        ace_unload_token = self._ace_claim_load(ch, kind='unload')
                    elif getattr(self.ace, '_u1_load_owner', None) is not None:
                        self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
                        raise ValueError('Another U1 operation owns ACE; refusing unrelated cancel')
                    self.ace._u1_unload_depth += 1
                    ace_unload_guard = True
                    ace_unload_connection = self.ace._connected_at
                    ace_unload_gate_epoch = self.ace._gate_epochs[self.filament_ch[ch]]
                    if ace_unload_token is not None:
                        try:
                            self._ace_check_unload(ch, ace_unload_token)
                        except Exception:
                            self.channel_error_state[ch] = self.channel_state[ch]
                            self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL)
                            raise
                self.exception_code[ch] = 70
                if stage not in [None, FEED_UNLOAD_STAGE_PREPARE, FEED_UNLOAD_STAGE_DOING,
                                 FEED_UNLOAD_STAGE_CANCEL]:
                    logging.error("[feed][unload] stage parameter error!\r\n")
                    self.toolhead.wait_moves()
                    self.channel_error[ch] = FEED_ERR_PARAMETER
                    self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL)
                    raise ValueError('parameter error!')

                self.manual_feeding[ch] = False
                self.channel_error_state[ch] = FEED_STA_NONE
                if stage == FEED_UNLOAD_STAGE_PREPARE:
                    try:
                        if self.ace is not None:
                            self.ace._stop_feed_assist_only()
                        # prepare
                        self._set_channel_state(ch, FEED_STA_UNLOAD_PREPARE, True)

                        # home
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_HOMING)
                            if self._check_homing_xy() != True:
                                self.gcode.run_script_from_command("G28 X Y\r\n")
                                self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_HOME
                            raise

                        # switch extruder
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_PICKING)
                            self.gcode.run_script_from_command("T%d A0\r\n" % (self.filament_ch[ch]))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_SWITCH
                            raise

                        # move to dest position
                        try:
                            self.gcode.run_script_from_command("MOVE_TO_DISCARD_FILAMENT_POSITION\r\n")
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE
                            raise

                        # heat
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_HEATING)
                            self.gcode.run_script_from_command("M109 S%d\r\n" % (filament_feed_temp))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_HEAT
                            raise

                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_UNLOAD_HEAT_FINISH)

                    except:
                        self.toolhead.wait_moves()
                        self.channel_error_state[ch] = self.channel_state[ch]
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL)
                        raise

                elif stage == FEED_UNLOAD_STAGE_DOING:
                    try:
                        # prepare for unloading?
                        if self.channel_state[ch] != FEED_STA_UNLOAD_HEAT_FINISH:
                            self.channel_error[ch] = FEED_ERR_STATE_MISMATCH
                            raise ValueError('state mismatch!')

                        if self.ace is not None:
                            if not self._ace_head_present(ch):
                                self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                                raise ValueError('No filament at U1 head; refusing another full retract')
                            self.ace._stop_feed_assist_only()

                        # unloading
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_DOING)
                            self.toolhead.wait_moves()
                            self.gcode.run_script_from_command("INNER_FILAMENT_UNLOAD TEMP=%d SOFT=%d NOZZLE_DIAMETER=%f\r\n"
                                                            % (filament_feed_temp, int(filament_soft), self.toolhead.get_extruder().nozzle_diameter))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                            raise ValueError('custom gcode error!')

                        # finish
                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("M104 S0\r\n")
                        if self.ace is not None:
                            self._ace_complete_unload(ch, ace_unload_token)
                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_UNLOAD_FINISH)

                    except:
                        self.toolhead.wait_moves()
                        self.channel_error_state[ch] = self.channel_state[ch]
                        self.gcode.run_script_from_command("M104 S0\r\n")
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL)
                        raise

                elif stage == FEED_UNLOAD_STAGE_CANCEL:
                    # Cooling/cancel state cleanup must run even if ACE is offline.
                    self.gcode.run_script_from_command("M104 S0\r\n")
                    self.toolhead.wait_moves()
                    self.channel_error[ch] = FEED_OK
                    self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL, True)
                    self.gcode.run_script_from_command("M104 S0\r\n")
                    if self.module_exist[ch] == True and self.config['auto_mode'][ch] == True:
                        if self._port[ch].get_filament_detected() == False:
                            self._set_channel_state(ch, FEED_STA_WAIT_INSERT)
                        else:
                            self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH)
                    if self.ace is not None:
                        try:
                            self.ace._stop_feed_assist_only()
                        except Exception:
                            self.channel_error[ch] = FEED_ERR
                            raise

                else:
                    try:
                        # prepare
                        if self.ace is not None:
                            self.ace._stop_feed_assist_only()
                        self._set_channel_state(ch, FEED_STA_UNLOAD_PREPARE, True)

                        # home
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_HOMING)
                            if self._check_homing_xy() != True:
                                self.gcode.run_script_from_command("G28 X Y\r\n")
                                self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_HOME
                            raise

                        # switch extruder
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_PICKING)
                            self.gcode.run_script_from_command("T%d A0\r\n" % (self.filament_ch[ch]))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_SWITCH
                            raise

                        # move to dest position
                        try:
                            self.gcode.run_script_from_command("MOVE_TO_DISCARD_FILAMENT_POSITION\r\n")
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE
                            raise

                        # heat
                        try:
                            self._set_channel_state(ch, FEED_STA_UNLOAD_HEATING)
                            self.gcode.run_script_from_command("M109 S%d\r\n" % (filament_feed_temp))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_HEAT
                            raise

                        try:
                            if self.ace is not None:
                                if not self._ace_head_present(ch):
                                    self.channel_error[ch] = FEED_ERR_NO_FILAMENT
                                    raise ValueError('No filament at U1 head before unloading')
                                self.ace._stop_feed_assist_only()
                            self._set_channel_state(ch, FEED_STA_UNLOAD_DOING)
                            self.toolhead.wait_moves()
                            self.gcode.run_script_from_command("INNER_FILAMENT_UNLOAD TEMP=%d SOFT=%d NOZZLE_DIAMETER=%f\r\n"
                                                            % (filament_feed_temp, int(filament_soft), self.toolhead.get_extruder().nozzle_diameter))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                            raise ValueError('custom gcode error!')

                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("M104 S0\r\n")
                        if self.ace is not None:
                            self._ace_complete_unload(ch, ace_unload_token)
                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_UNLOAD_FINISH)

                    except:
                        self.toolhead.wait_moves()
                        self.channel_error_state[ch] = self.channel_state[ch]
                        self.gcode.run_script_from_command("M104 S0\r\n")
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_UNLOAD_FAIL)
                        raise

            # manually feed
            elif action == FEED_ACT_MANUAL_FEED:
                self.exception_code[ch] = 90
                if stage not in [FEED_MANUAL_STAGE_PREPARE, FEED_MANUAL_STAGE_EXTRUDE,
                                 FEED_MANUAL_STAGE_FLUSH, FEED_MANUAL_STAGE_FINISH,
                                 FEED_MANUAL_STAGE_CANCEL]:
                    logging.error("[feed][manual] stage parameter error!\r\n")
                    self.toolhead.wait_moves()
                    self.channel_error[ch] = FEED_ERR_PARAMETER
                    self._set_channel_state(ch, FEED_STA_MANUAL_FAIL)
                    raise ValueError('parameter error!')

                self.channel_error_state[ch] = FEED_STA_NONE
                if stage == FEED_MANUAL_STAGE_PREPARE:
                    try:
                        self._set_channel_state(ch, FEED_STA_MANUAL_PREPARE, True)
                        self.manual_feeding[ch] = True

                        # home
                        try:
                            self._set_channel_state(ch, FEED_STA_MANUAL_HOMING)
                            if self._check_homing_xy() != True:
                                self.gcode.run_script_from_command("G28 X Y\r\n")
                                self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_HOME
                            raise

                        # switch extruder
                        try:
                            self._set_channel_state(ch, FEED_STA_MANUAL_PICKING)
                            self.gcode.run_script_from_command("T%d A0\r\n" % (self.filament_ch[ch]))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_MOVE_SWITCH
                            raise

                        try:
                            self.toolhead.wait_moves()
                            self.gcode.run_script_from_command("INNER_MANUAL_FEED_STAGE_PREPARE\r\n")
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                            raise ValueError('custom gcode error!')

                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_MANUAL_PREPARE_FINISH)

                    except:
                        self.manual_feeding[ch] = False
                        self.toolhead.wait_moves()
                        self.channel_error_state[ch] = self.channel_state[ch]
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_MANUAL_PREPARE_FAIL)
                        raise

                elif stage == FEED_MANUAL_STAGE_EXTRUDE:
                    try:
                        # heat
                        try:
                            self._set_channel_state(ch, FEED_STA_MANUAL_HEATING, True)
                            self.gcode.run_script_from_command("M109 S%d\r\n" % (filament_feed_temp))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_HEAT
                            raise

                        # extrude
                        try:
                            self._set_channel_state(ch, FEED_STA_MANUAL_EXTRUDING)
                            self.toolhead.wait_moves()
                            self.gcode.run_script_from_command("INNER_MANUAL_FEED_STAGE_EXTRUDE TEMP=%d SOFT=%d NOZZLE_DIAMETER=%f\r\n" %
                                                               (filament_feed_temp, int(filament_soft), self.toolhead.get_extruder().nozzle_diameter))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                            raise ValueError('custom gcode error!')

                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_MANUAL_EXTRUDE_FINISH)

                    except:
                        self.toolhead.wait_moves()
                        self.manual_feeding[ch] = False
                        self.channel_error_state[ch] = self.channel_state[ch]
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_MANUAL_EXTRUDE_FAIL)
                        raise

                elif stage == FEED_MANUAL_STAGE_FLUSH:
                    try:
                        # flush
                        try:
                            self.toolhead.wait_moves()
                            self._set_channel_state(ch, FEED_STA_MANUAL_FLUSHING, True)
                            self.gcode.run_script_from_command("INNER_MANUAL_FEED_STAGE_FLUSH TEMP=%d SOFT=%d NOZZLE_DIAMETER=%f\r\n" %
                                                (filament_feed_temp, int(filament_soft), self.toolhead.get_extruder().nozzle_diameter))
                            self.toolhead.wait_moves()
                        except:
                            self.channel_error[ch] = FEED_ERR_CUSTOM_GCODE
                            raise ValueError('custom gcode error!')

                        self.channel_error[ch] = FEED_OK
                        self._set_channel_state(ch, FEED_STA_MANUAL_FLUSH_FINISH)

                    except:
                        self.toolhead.wait_moves()
                        self.manual_feeding[ch] = False
                        self.channel_error_state[ch] = self.channel_state[ch]
                        if self.channel_error[ch] == FEED_OK:
                            self.channel_error[ch] = FEED_ERR
                        self._set_channel_state(ch, FEED_STA_MANUAL_FLUSH_FAIL)
                        raise

                elif stage == FEED_MANUAL_STAGE_FINISH:
                    self.manual_feeding[ch] = False
                    try:
                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("INNER_MANUAL_FEED_STAGE_FINISH\r\n")
                        self.toolhead.wait_moves()
                    except:
                        logging.error("[feed][manual] stage: finish, gcode error\r\n")
                        self._set_channel_state(ch, FEED_STA_MANUAL_FAIL)
                        self.channel_error_state[ch] = self.channel_state[ch]
                        raise
                    self._set_channel_state(ch, FEED_STA_MANUAL_FINISH, True)
                    # The delay here is for the convenience of updating the status to the client
                    self.reactor.pause(self.reactor.monotonic() + 0.26)
                    self._set_channel_state(ch, FEED_STA_LOAD_FINISH, True)

                    if self.runout_sensor[ch] is not None and \
                            self.runout_sensor[ch].get_status(0)['enabled'] == True and \
                            self.runout_sensor[ch].get_status(0)['filament_detected'] == False:
                        if self.module_exist[ch] == True and self.config['auto_mode'][ch] == True:
                            if self._port[ch].get_filament_detected() == False:
                                self._set_channel_state(ch, FEED_STA_WAIT_INSERT, True)
                            else:
                                self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH, True)
                        else:
                            self._set_channel_state(ch, FEED_STA_NONE, True)


                elif stage == FEED_MANUAL_STAGE_CANCEL:
                    self.manual_feeding[ch] = False
                    try:
                        self.toolhead.wait_moves()
                        self.gcode.run_script_from_command("INNER_MANUAL_FEED_STAGE_CANCEL\r\n")
                        self.toolhead.wait_moves()
                    except:
                        logging.error("[feed][manual] stage: cancel, gcode error!\r\n")
                    self._set_channel_state(ch, FEED_STA_MANUAL_FAIL, True)
                    self.channel_error_state[ch] = self.channel_state[ch]

                    if self.module_exist[ch] == True and self.config['auto_mode'][ch] == True:
                        if self._port[ch].get_filament_detected() == False:
                            self._set_channel_state(ch, FEED_STA_WAIT_INSERT)
                        else:
                            self._set_channel_state(ch, FEED_STA_PRELOAD_FINISH)
                else:
                    logging.error("[feed][manual] stage parameter error!\r\n")

        except:
            raise

        finally:
            if (action == FEED_ACT_UNLOAD and self.channel_error[ch] != FEED_OK
                    and (self.ace is None or ace_unload_guard)):
                try:
                    self.gcode.run_script_from_command("M104 S0\r\n")
                except Exception as cleanup:
                    logging.error('Unload failure heater cleanup failed: %s', cleanup)
                if (self.ace is not None and self.ace._connected
                        and self.ace._connected_at == ace_unload_connection
                        and (getattr(self.ace, '_u1_load_owner', None) is ace_unload_token
                             or (stage == FEED_UNLOAD_STAGE_CANCEL
                                 and getattr(self.ace, '_u1_load_owner', None) is None))):
                    try:
                        self.ace._stop_feed_assist_only()
                    except Exception as cleanup:
                        self.ace.log_error('ACE unload-failure assist cleanup failed: %s' % (cleanup,))
            if ace_load_token is not None:
                ace = self.ace
                if (getattr(ace, '_u1_load_owner', None) is ace_load_token
                        and ace._connected and ace._connected_at == ace_load_token['connection']
                        and self.channel_error[ch] != FEED_OK):
                    try:
                        ace._stop_feed_assist_only()
                    except Exception as cleanup:
                        ace.log_error('ACE load-failure assist cleanup failed: %s' % (cleanup,))
                if getattr(ace, '_u1_load_owner', None) is ace_load_token:
                    ace._u1_load_owner = None
            if (ace_unload_token is not None
                    and getattr(self.ace, '_u1_load_owner', None) is ace_unload_token):
                self.ace._u1_load_owner = None
            if ace_unload_guard:
                self.ace._u1_unload_depth -= 1
            self.channel_active = None

    def get_status(self, eventtime=None):
        filament_detected = []
        filament_detected.append(self._port[FEED_CHANNEL_1].get_filament_detected())
        filament_detected.append(self._port[FEED_CHANNEL_2].get_filament_detected())

        channel_1_dist = {
            'module_exist': self.module_exist[FEED_CHANNEL_1],
            'filament_detected': filament_detected[FEED_CHANNEL_1],
            'disable_auto': not self.config['auto_mode'][FEED_CHANNEL_1],
            'channel_state':self.channel_state[FEED_CHANNEL_1],
            'channel_error':self.channel_error[FEED_CHANNEL_1],
            'channel_error_state': self.channel_error_state[FEED_CHANNEL_1],
            'channel_action_state': self.channel_action_state[FEED_CHANNEL_1]
        }
        channel_2_dist = {
            'module_exist': self.module_exist[FEED_CHANNEL_2],
            'filament_detected': filament_detected[FEED_CHANNEL_2],
            'disable_auto': not self.config['auto_mode'][FEED_CHANNEL_2],
            'channel_state':self.channel_state[FEED_CHANNEL_2],
            'channel_error':self.channel_error[FEED_CHANNEL_2],
            'channel_error_state': self.channel_error_state[FEED_CHANNEL_2],
            'channel_action_state': self.channel_action_state[FEED_CHANNEL_2]
        }

        return {
            f'extruder{self.filament_ch[FEED_CHANNEL_1]}': channel_1_dist,
            f'extruder{self.filament_ch[FEED_CHANNEL_2]}': channel_2_dist}

    def cmd_FEED_LIGHT(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        index = gcmd.get('INDEX').upper()
        value = gcmd.get_int('VALUE', minval=0, maxval=1)

        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        if not index in FEED_LIGHT_INDEXS:
            raise gcmd.error("[feed] light index[%s] is error" % (index))

        systime = self.reactor.monotonic()
        systime += FEED_MIN_TIME
        print_time = self.light[channel].get_mcu().estimated_print_time(systime)
        self.light[channel].set_light_state(print_time, FEED_STA_TEST, index, value)
        self._last_print_time = print_time

    def cmd_FEED_PORT(self, gcmd):
        channel = gcmd.get_int('CHANNEL')

        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        adc_value = self._port[channel].get_adc_value()
        present = None
        if (self._port[channel].get_filament_detected()):
            present = "detected"
        else:
            present = "not detected"

        msg = ("port[%d]: adc value = %f, filament: %s\n" % (
                channel, adc_value, present))
        gcmd.respond_info(msg, log=False)

    def cmd_FEED_WHEEL_TACH(self, gcmd):
        channel = gcmd.get_int('CHANNEL')

        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        msg = ( "rpm: %d\n"
                "cnt: %d\n"
                "rpm2: %d\n"
                "cnt2: %d\n"
                % ( self.wheel[channel].get_rpm(),
                    self.wheel[channel].get_counts(),
                    self.wheel_2[channel].get_rpm(),
                    self.wheel_2[channel].get_counts()))
        gcmd.respond_info(msg, log=False)

    def cmd_FEED_MOTOR(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        value = gcmd.get_float('VALUE')

        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        if channel == FEED_CHANNEL_1:
            self.motor.run(FEED_MOTOR_DIR_A, value)
        else:
            self.motor.run(FEED_MOTOR_DIR_B, value)

    def cmd_FEED_MOTOR_ONE_CYCLE(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        value = gcmd.get_float('VALUE')
        time = gcmd.get_float('TIME', self.motor_hang_neutral_time)

        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        if channel == FEED_CHANNEL_1:
            self.motor.run_one_cycle(FEED_MOTOR_DIR_A, value, time)
        else:
            self.motor.run_one_cycle(FEED_MOTOR_DIR_B, value, time)

    def cmd_FEED_MOTOR_TACH(self, gcmd):
        msg = ( "rpm: %d\n"
                "cnt: %d\n"
                % ( self.motor_tachometer.get_rpm(),
                    self.motor_tachometer.get_counts()))
        gcmd.respond_info(msg, log=False)

    def cmd_FEED_AUTO(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))
        auto_mode = gcmd.get_int('AUTO', None)
        if auto_mode is not None:
            auto_mode = bool(auto_mode)
        need_to_load = gcmd.get_int('LOAD', None)
        if need_to_load is not None:
            need_to_load = bool(need_to_load)
        need_to_unload = gcmd.get_int('UNLOAD', None)
        if need_to_unload is not None:
            need_to_unload = bool(need_to_unload)
        stage = gcmd.get('STAGE', None)
        if stage is not None:
            stage = stage.lower()
        is_printing = gcmd.get_int('PRINTING', 0, minval=0, maxval=1)
        need_save = gcmd.get_int('SAVE', 1, minval=0, maxval=1)
        restore_temp_from_cmd = gcmd.get_float('RESTORE_TEMP', None)

        raw_msg = None
        msg = None

        logging.info("[feed] FEED_AUTO %s", gcmd.get_raw_command_parameters())
        logging.info(f"[feed] current state: {self.get_status()}")

        filament_entangle_detect = self.printer.lookup_object(
                f'filament_entangle_detect e{self.filament_ch[channel]}_filament', None)
        machine_state_manager = self.printer.lookup_object('machine_state_manager', None)
        extruder_obj = self.printer.lookup_object("extruder", None)
        if self.filament_ch[channel] != 0:
            extruder_obj = self.printer.lookup_object(f"extruder{self.filament_ch[channel]}", None)
        if machine_state_manager is not None:
            machine_sta = machine_state_manager.get_status()
            if str(machine_sta["main_state"]) not in ["IDLE", "PRINTING", "AUTO_LOAD", "AUTO_UNLOAD" ]:
                raise gcmd.error('[feed] channel[%d] machine main state error: %s\n'
                                 % (channel, str(machine_sta["main_state"])))

        if auto_mode is not None:
            try:
                self._do_feed(channel, FEED_ACT_UPDATE_AUTO_MODE, auto_mode=auto_mode)
            except:
                raise gcmd.error(
                        message = '[feed] channel[%d]: set auto mode error \n' % (channel),
                        action = 'none',
                        id = 525,
                        index = self.filament_ch[channel],
                        code = 0,
                        oneshot = 1,
                        level = 2)

            if need_save:
                load_config = self.printer.load_snapmaker_config_file(self.config_path, FEED_DEFAULT_CONFIG)
                load_config['auto_mode'] = self.config['auto_mode']
                ret = self.printer.update_snapmaker_config_file(self.config_path, load_config, FEED_DEFAULT_CONFIG)
                if not ret:
                    logging.error("[feed] save auto_mode failed!")
            return

        if need_to_load == True:
            if (self.channel_state[channel] == FEED_STA_LOAD_FINISH
                    and self.channel_error[channel] == FEED_OK
                    and (self.ace is None or self._ace_head_present(channel))):
                return

            if is_printing == 1 and self._port[channel].get_filament_detected() == False:
                return

            if self.module_exist[channel] == False or self.config['auto_mode'][channel] == False:
                return

            if self.runout_sensor[channel] is None or self.runout_sensor[channel].get_status(0)['enabled'] == False:
                return

            last_temp = 0
            need_restore_temp = False
            if extruder_obj is not None:
                last_temp = extruder_obj.heater.target_temp
            try:
                if machine_state_manager is not None:
                    machine_sta = machine_state_manager.get_status()
                    if str(machine_sta["main_state"]) == "PRINTING":
                        need_restore_temp = True
                        if str(machine_sta["action_code"]) != "PRINT_RESUMING" and str(machine_sta["action_code"]) != "PRINT_REPLENISHING":
                            self.gcode.run_script_from_command("SET_ACTION_CODE ACTION=PRINT_AUTO_FEEDING")
                    else:
                        self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=AUTO_LOAD ACTION=AUTO_LOADING")
                    self.toolhead.wait_moves()
                if filament_entangle_detect is not None:
                    filament_entangle_detect.skip_entangle_check(True)
                self._do_feed(channel, FEED_ACT_LOAD)
            except Exception as e:
                raw_msg =  self.printer.extract_coded_message_field(str(e))
                logging.error("[feed][load] channel[%d] auto load error: %s", channel, raw_msg)
                if self._is_keep_raw_error_info(self.channel_error[channel]):
                    raise
            finally:
                if need_restore_temp == True:
                    if restore_temp_from_cmd is not None:
                        self.gcode.run_script_from_command(f"M104 S{restore_temp_from_cmd} T{self.filament_ch[channel]} A0")
                    else:
                        self.gcode.run_script_from_command(f"M104 S{last_temp} T{self.filament_ch[channel]} A0")
                if filament_entangle_detect is not None:
                    filament_entangle_detect.skip_entangle_check(False)
                if machine_state_manager is not None:
                    machine_sta = machine_state_manager.get_status()
                    if str(machine_sta["main_state"]) == "PRINTING":
                        if str(machine_sta["action_code"]) != "PRINT_RESUMING" and str(machine_sta["action_code"]) != "PRINT_REPLENISHING":
                            self.gcode.run_script_from_command("SET_ACTION_CODE ACTION=IDLE")
                    else:
                        self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE")
                    self.toolhead.wait_moves()

            if self.channel_state[channel] != FEED_STA_LOAD_FINISH or self.channel_error[channel] != FEED_OK:
                msg = 'extruder[%d]: state: %s, error: %s!' % (
                        self.filament_ch[channel],
                        self.channel_error_state[channel],
                        self.channel_error[channel])
                if raw_msg is not None:
                    msg = msg + "raw msg:" + raw_msg

                raise gcmd.error(
                        message = msg,
                        action = 'pause',
                        id = 525,
                        index = self.filament_ch[channel],
                        code = self.exception_code[channel],
                        oneshot = 1,
                        level = 2)

            return

        if need_to_unload == True:
            if (self.ace is not None and stage in (None, FEED_UNLOAD_STAGE_PREPARE)
                    and self.channel_state[channel] != FEED_STA_UNLOAD_HEAT_FINISH
                    and not self._ace_head_present(channel)):
                # No transport is needed for a newly inserted or already parked
                # spool. Unknown failed positions must not be called parked.
                if self.channel_state[channel] in (FEED_STA_LOAD_FAIL, FEED_STA_UNLOAD_FAIL):
                    raise gcmd.error('Filament position is uncertain after a failed operation; check the path before unloading')
                gcmd.respond_info('No filament at U1 head; ACE filament left in place')
                return
            last_temp = 0
            need_restore_temp = False
            if extruder_obj is not None:
                last_temp = extruder_obj.heater.target_temp
            try:
                if filament_entangle_detect is not None:
                    filament_entangle_detect.skip_entangle_check(True)
                if machine_state_manager is not None:
                    machine_sta = machine_state_manager.get_status()
                    if str(machine_sta["main_state"]) == "PRINTING":
                        need_restore_temp = True
                        self.gcode.run_script_from_command("SET_ACTION_CODE ACTION=PRINT_AUTO_UNLOADING")
                    else:
                        self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=AUTO_UNLOAD ACTION=AUTO_UNLOADING")
                self._do_feed(channel, FEED_ACT_UNLOAD, stage=stage)
            except Exception as e:
                if machine_state_manager is not None:
                    machine_sta = machine_state_manager.get_status()
                    if str(machine_sta["main_state"]) == "PRINTING":
                        self.gcode.run_script_from_command("SET_ACTION_CODE ACTION=IDLE")
                    else:
                        self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE")
                raw_msg =  self.printer.extract_coded_message_field(str(e))
                logging.error("[feed][unload] channel[%d]: auto unload error: %s", channel, raw_msg)
                if self._is_keep_raw_error_info(self.channel_error[channel]):
                    raise
            else:
                # cancel or finish
                if stage in [None, FEED_UNLOAD_STAGE_DOING, FEED_UNLOAD_STAGE_CANCEL]:
                    if machine_state_manager is not None:
                        machine_sta = machine_state_manager.get_status()
                        if str(machine_sta["main_state"]) == "PRINTING":
                            self.gcode.run_script_from_command("SET_ACTION_CODE ACTION=IDLE")
                        else:
                            self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE")
            finally:
                if need_restore_temp == True:
                    if restore_temp_from_cmd is not None:
                        self.gcode.run_script_from_command(f"M104 S{restore_temp_from_cmd} T{self.filament_ch[channel]} A0")
                    else:
                        self.gcode.run_script_from_command(f"M104 S{last_temp} T{self.filament_ch[channel]} A0")
                if filament_entangle_detect is not None:
                    filament_entangle_detect.skip_entangle_check(False)

            if self.channel_error[channel] != FEED_OK:
                msg = 'extruder[%d]: state: %s, error: %s!' % (
                        self.filament_ch[channel],
                        self.channel_error_state[channel],
                        self.channel_error[channel])
                if raw_msg is not None:
                    msg = msg + "raw msg:" + raw_msg

                raise gcmd.error(
                        message = msg,
                        action = 'pause',
                        id = 525,
                        index = self.filament_ch[channel],
                        code = self.exception_code[channel],
                        oneshot = 1,
                        level = 2)

            return

    def cmd_FEED_MANUAL(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed][manual_load] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))
        stage = gcmd.get('STAGE').lower()
        if stage not in [FEED_MANUAL_STAGE_PREPARE, FEED_MANUAL_STAGE_EXTRUDE,
                         FEED_MANUAL_STAGE_FLUSH, FEED_MANUAL_STAGE_FINISH,
                         FEED_MANUAL_STAGE_CANCEL]:
            raise gcmd.error('[feed][manual_load] stage error: %s\n' % (stage))

        raw_msg = None
        msg = None

        logging.info("[feed] FEED_MANUAL %s", gcmd.get_raw_command_parameters())

        filament_entangle_detect = self.printer.lookup_object(
                f'filament_entangle_detect e{self.filament_ch[channel]}_filament', None)
        machine_state_manager = self.printer.lookup_object('machine_state_manager', None)
        extruder_obj = self.printer.lookup_object("extruder", None)
        if self.filament_ch[channel] != 0:
            extruder_obj = self.printer.lookup_object(f"extruder{self.filament_ch[channel]}", None)
        if machine_state_manager is not None:
            machine_sta = machine_state_manager.get_status()
            if str(machine_sta["main_state"]) not in ["IDLE", "PRINTING", "MANUAL_LOAD"]:
                raise gcmd.error('[feed][manual] channel[%d] machine main state error: %s\n'
                                 % (channel, str(machine_sta["main_state"])))

        last_temp = 0
        need_restore_temp = False
        if extruder_obj is not None:
            last_temp = extruder_obj.heater.target_temp

        try:
            if filament_entangle_detect is not None:
                filament_entangle_detect.skip_entangle_check(True)
            if machine_state_manager is not None:
                machine_sta = machine_state_manager.get_status()
                if str(machine_sta["main_state"]) != "PRINTING":
                    self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=MANUAL_LOAD ACTION=MANUAL_LOADING")
                else:
                    need_restore_temp = True
            self._do_feed(channel, FEED_ACT_MANUAL_FEED, stage)
        except Exception as e:
            if machine_state_manager is not None:
                machine_sta = machine_state_manager.get_status()
                if str(machine_sta["main_state"]) != "PRINTING":
                    self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE")
            raw_msg =  self.printer.extract_coded_message_field(str(e))
            logging.error("[feed][manual] channel[%d]: manual load error: %s", channel, raw_msg)
            if self._is_keep_raw_error_info(self.channel_error[channel]):
                raise
        else:
            # cancel or finish
            if stage in [FEED_MANUAL_STAGE_FINISH, FEED_MANUAL_STAGE_CANCEL]:
                if machine_state_manager is not None:
                    machine_sta = machine_state_manager.get_status()
                    if str(machine_sta["main_state"]) != "PRINTING":
                        self.gcode.run_script_from_command("SET_MAIN_STATE MAIN_STATE=IDLE ACTION=IDLE")
        finally:
            if need_restore_temp == True:
                self.gcode.run_script_from_command(f"M104 S{last_temp} T{self.filament_ch[channel]} A0")
            if filament_entangle_detect is not None:
                filament_entangle_detect.skip_entangle_check(False)

        if self.channel_error[channel] != FEED_OK:
            msg = 'extruder[%d]: state: %s, error: %s!' % (
                    self.filament_ch[channel],
                    self.channel_error_state[channel],
                    self.channel_error[channel])
            if raw_msg is not None:
                msg = msg + "raw msg:" + raw_msg

            raise gcmd.error(
                    message = msg,
                    action = 'pause',
                    id = 525,
                    index = self.filament_ch[channel],
                    code = self.exception_code[channel],
                    oneshot = 1,
                    level = 2)
    def cmd_FEED_RUNOUT_EVENT_HANDLE(self, gcmd):
        channel = gcmd.get_int('CHANNEL')
        if channel < 0 or channel >= FEED_CHANNEL_NUMS:
            raise gcmd.error('[feed] channel[%d] is out of range[0,%d]\n' % (channel, FEED_CHANNEL_NUMS - 1))

        self.toolhead.wait_moves()
        try:
            self._do_feed(channel, FEED_ACT_FILAMENT_RUNOUT)
        except:
            logging.error("[feed] channel[%d]: runout event handle error!", channel)
        if self.ace is not None:
            self._ace_runout_begin(channel)

def load_config_prefix(config):
    return FilamentFeed(config)

