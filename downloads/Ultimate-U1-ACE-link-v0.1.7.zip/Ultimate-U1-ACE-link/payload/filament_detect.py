import logging, os
from . import filament_protocol
from . import filament_protocol_ndef
from . import fm175xx_reader

# Error code
FILAMENT_DT_OK                                  = 0
FILAMENT_DT_ERR                                 = -1
FILAMENT_DT_PARAM_ERR                           = -2

# State
FILAMENT_DT_STATE_IDLE                          = 0
FILAMENT_DT_STATE_DETECTING                     = 1
FILAMENT_DT_STATE_SELF_TESTING                  = 2

FILAMENT_DT_CHANNEL_NUMS                        = 4
FILAMENT_DT_CONFIG_FILE                         = "filament_detect.json"

DEFAULT_FILAMENT_DT_CONFIG = {
    'startup_stay': False
}

class FilamentDetector:
    def __init__(self, config) -> None:
        self.printer = config.get_printer()
        self.reactor = self.printer.get_reactor()

        config_dir = self.printer.get_snapmaker_config_dir()
        config_name = FILAMENT_DT_CONFIG_FILE
        self._config_path = os.path.join(config_dir, config_name)

        self._config = self.printer.load_snapmaker_config_file(self._config_path, DEFAULT_FILAMENT_DT_CONFIG)

        self._channel_nums = FILAMENT_DT_CHANNEL_NUMS
        self._filament_info = [dict(filament_protocol.FILAMENT_INFO_STRUCT) for i in range(self._channel_nums)]
        self._state = [FILAMENT_DT_STATE_IDLE for i in range(self._channel_nums)]
        self._notify_data_update_cb = []
        self._ace_clear_stamps = [None] * self._channel_nums

        self.filament_feed_objects = None
        self._fm175xx_reader = None
        self._self_test_success_cnt = 0

        gcode = self.printer.lookup_object('gcode')
        gcode.register_command('FILAMENT_DT_QUERY', self.cmd_FILAMENT_DT_QUERY)
        gcode.register_command('FILAMENT_DT_UPDATE', self.cmd_FILAMENT_DT_UPDATE)
        gcode.register_command('FILAMENT_DT_CLEAR', self.cmd_FILAMENT_DT_CLEAR)
        gcode.register_command('FILAMENT_DT_SELF_TEST', self.cmd_FILAMENT_DT_SELF_TEST)
        gcode.register_command('FILAMENT_DT_STARTUP_STAY', self.cmd_FILAMENT_DT_STARTUP_STAY)

        self.printer.register_event_handler("klippy:ready", self._ready)
        self.printer.register_event_handler("filament_feed:port", self._feed_port_evt_handle)
        self.printer.register_event_handler("filament_switch_sensor:runout", self._runout_evt_handle)
        self.printer.register_event_handler("ace:gate_changed", self._ace_gate_changed)

        self.webhooks = self.printer.lookup_object('webhooks')
        self.webhooks.register_endpoint("filament_detect/set", self._handle_filament_detect_set)

    def _ready(self):
        self.filament_feed_objects = self.printer.lookup_objects('filament_feed')
        self._fm175xx_reader = self.printer.lookup_object('fm175xx_reader')
        if not self._fm175xx_reader.enabled:
            self._fm175xx_reader = None
        if (self._fm175xx_reader is not None):
            self._fm175xx_reader.register_cb_2_card_info_deal(self._fm175xx_card_info_deal_callback)

        if self._config['startup_stay'] == False and self.printer.lookup_object('ace', None) is None:
            for i in range(self._channel_nums):
                filament_sensor = self.printer.lookup_object('filament_motion_sensor e%d_filament' % (i))
                if filament_sensor.get_status(0)['filament_detected'] and filament_sensor.get_status(0)['enabled']:
                    self.request_update_filament_info(i)

    def _feed_port_evt_handle(self, channel, detect):
        if self.printer.lookup_object('ace', None) is not None:
            return
        filament_sensor = self.printer.lookup_object('filament_motion_sensor e%d_filament' % (channel))
        filament_sensor_status = filament_sensor.get_status(0)

        if filament_sensor_status['filament_detected'] and filament_sensor_status['enabled']:
            pass
        else:
            if detect:
                self.request_update_filament_info(channel)
            else:
                self.request_clear_filament_info(channel)

    def _ace_head_holds_filament(self, channel):
        sensor = self.printer.lookup_object('filament_motion_sensor e%d_filament' % (channel), None)
        if sensor is None:
            return False
        status = sensor.get_status(0)
        return bool(status['enabled'] and status['filament_detected'])

    def _ace_print_active(self):
        print_stats = self.printer.lookup_object('print_stats', None)
        return print_stats is not None and print_stats.state in ('printing', 'paused')

    def _runout_evt_handle(self, extruder, present):
        ace = self.printer.lookup_object('ace', None)
        if ace is not None:
            # A spool tail that already left the ACE kept its material data
            # while it fed the head. Outside a print, an empty head ends that.
            if (not present and type(extruder) is int and 0 <= extruder < self._channel_nums
                    and not self._ace_print_active()):
                self._ace_clear_material(extruder, ace)
            return
        filament_feed_infos = {}
        for obj_name, obj in self.filament_feed_objects:
            status = obj.get_status(0)
            filament_feed_infos.update(status)
        e_obj = filament_feed_infos.get('extruder%d' % (extruder), None)

        if e_obj is not None and e_obj['module_exist'] and not e_obj['disable_auto']:
            if present:
                self.request_update_filament_info(extruder)
            else:
                if e_obj['filament_detected'] == True:
                    self.request_clear_filament_info(extruder)
                    self.request_update_filament_info(extruder)
                else:
                    self.request_clear_filament_info(extruder)
        else:
            if present:
                self.request_update_filament_info(extruder)
            else:
                self.request_clear_filament_info(extruder)

    def _ace_clear_current(self, channel, ace, stamp, require_fresh=True):
        if (self.printer.lookup_object('ace', None) is not ace
                or ace._connected_at != stamp[0]
                or ace._gate_epochs[channel] != stamp[1]):
            return False
        status = ace.get_status(self.reactor.monotonic())
        return (status['connected'] and (not require_fresh or status['status_fresh'])
                and status['gate_status'][channel] == 0)

    def _ace_gate_changed(self, channel, present):
        if type(channel) is not int or not 0 <= channel < self._channel_nums:
            return
        ace = self.printer.lookup_object('ace', None)
        if ace is None:
            return
        if present:
            self._ace_clear_stamps[channel] = None
            return
        if self._ace_print_active() and self._ace_head_holds_filament(channel):
            # The tail is still feeding the U1 head: the print continues with
            # this material, and a runout resume needs its data.
            return
        self._ace_clear_material(channel, ace)

    def _ace_clear_material(self, channel, ace):
        stamp = (ace._connected_at, ace._gate_epochs[channel])
        if (self._ace_clear_stamps[channel] == stamp
                or not self._ace_clear_current(channel, ace, stamp)):
            return
        self._ace_clear_stamps[channel] = stamp
        self._state[channel] = FILAMENT_DT_STATE_IDLE
        # ACE owns the source reader. Clear the local metadata only, and never
        # let this old removal's async notification erase a newly inserted spool.
        # Freshness was checked at the edge. An unrelated control command may
        # advance the status epoch before notification; gate/connection epochs
        # still prove that this confirmed removal has not been superseded.
        self._filament_info_update(channel, dict(filament_protocol.FILAMENT_INFO_STRUCT), True,
            _guard=lambda: self._ace_clear_current(channel, ace, stamp, require_fresh=False))

    def _filament_info_update(self, channel, info, is_clear=False, _guard=None):
        if _guard is not None and not _guard():
            return
        info['CARD_EVENT_TIME'] = self.reactor.monotonic()
        self._filament_info[channel] = info

        # notify
        if (0 != len(self._notify_data_update_cb)):
            for i in range(len(self._notify_data_update_cb)):
                self.reactor.register_async_callback(
                    (lambda et, c=self._notify_data_update_cb[i],
                        info=self._filament_info[channel], guard=_guard:
                            c(channel, info, is_clear) if guard is None or guard() else None))

    def _fm175xx_card_info_deal_callback(self, channel, operation, result, card_type, card_data):
        filament_info = None
        is_clear = False

        if channel < 0 or channel >= self._channel_nums:
            return

        if (fm175xx_reader.FM175XX_CARD_INFO_READ == operation):
            if (fm175xx_reader.FM175XX_MIFARE_CARD_TYPE_M1 == card_type and  fm175xx_reader.FM175XX_OK == result):
                logging.info("channel[%d] m1 card data parsing....", channel)
                error, info = filament_protocol.m1_proto_data_parse(card_data)
                if (error == filament_protocol.FILAMENT_PROTO_OK):
                    logging.info("channel[%d] m1 parse ok....", channel)
                    filament_info = info
                else:
                    logging.error("channel[%d] m1 parse err: %d", channel, error)
            elif fm175xx_reader.FM175XX_MIFARE_CARD_TYPE_NTAG == card_type and fm175xx_reader.FM175XX_OK == result:
                logging.info("channel[%d] trying NDEF parsing....", channel)
                error, info = filament_protocol_ndef.ndef_proto_data_parse(card_data)
                if (error == filament_protocol.FILAMENT_PROTO_OK):
                    logging.info("channel[%d] NDEF parse ok....", channel)
                    filament_info = info
                else:
                    logging.error("channel[%d] NDEF parse err....", channel)
        else:
            is_clear = True

        if (filament_info is None):
            filament_info = dict(filament_protocol.FILAMENT_INFO_STRUCT)
        else:
            self._self_test_success_cnt += 1

        if fm175xx_reader.FM175XX_CARD_INFO_READ == operation:
            if card_type == fm175xx_reader.FM175XX_MIFARE_CARD_TYPE_NTAG:
                filament_info['CARD_TYPE'] = 'NTAG'
                if card_data and len(card_data) >= 8:
                    filament_info['CARD_UID'] = [card_data[0], card_data[1], card_data[2],
                                                 card_data[4], card_data[5], card_data[6], card_data[7]]
            elif card_type == fm175xx_reader.FM175XX_MIFARE_CARD_TYPE_M1:
                filament_info['CARD_TYPE'] = 'M1'
                if card_data and len(card_data) >= filament_protocol.M1_PROTO_UID_LEN:
                    filament_info['CARD_UID'] = list(card_data[:filament_protocol.M1_PROTO_UID_LEN])

        self._state[channel] = FILAMENT_DT_STATE_IDLE
        self._filament_info_update(channel, filament_info, is_clear)

    def register_cb_2_update_filament_info(self, cb):
        try:
            if callable(cb):
                self._notify_data_update_cb.append(cb)
            else:
                raise TypeError()
        except Exception as e:
            logging.error("Param[cb] is not a callable function")

    def request_update_filament_info(self, channel):
        if channel < 0 or channel >= self._channel_nums:
            return

        self._state[channel] = FILAMENT_DT_STATE_DETECTING
        if self._fm175xx_reader is not None:
            self._fm175xx_reader.request_read_card_info(channel)

    def request_clear_filament_info(self, channel):
        if channel < 0 or channel >= self._channel_nums:
            return

        if self._fm175xx_reader is not None:
            self._state[channel] = FILAMENT_DT_STATE_DETECTING
            self._fm175xx_reader.request_clear_card_info(channel)
        else:
            self._state[channel] = FILAMENT_DT_STATE_IDLE
            self._filament_info_update(channel, dict(filament_protocol.FILAMENT_INFO_STRUCT), True)

    def get_a_filament_info(self, channel):
        error = FILAMENT_DT_ERR
        info = None

        if channel < 0 or channel >= self._channel_nums:
            error = FILAMENT_DT_PARAM_ERR
        else:
            error = FILAMENT_DT_OK
            info = self._filament_info[channel]

        return error, info

    def _handle_filament_detect_set(self, web_request):
        try:
            channel = web_request.get_int('channel', None)
            if channel is None:
                raise web_request.error("channel must be specified!")

            if (channel < 0 or channel >= self._channel_nums):
                raise web_request.error("channel[%d] is out of range[0, %d]"
                                        % (channel, self._channel_nums - 1))

            params = web_request.get_dict('info', {})
            filament_info = dict(filament_protocol.FILAMENT_INFO_STRUCT)
            if 'CARD_UID' in params:
                filament_info['CARD_UID'] = [int(b) for b in params.pop('CARD_UID')]
            if 'CARD_TYPE' in params:
                filament_info['CARD_TYPE'] = str(params.pop('CARD_TYPE'))

            has_params = len(params) > 0
            if 'VENDOR' in params:
                filament_info['VENDOR'] = str(params.pop('VENDOR'))
            if 'MAIN_TYPE' in params:
                filament_info['MAIN_TYPE'] = str(params.pop('MAIN_TYPE'))
            if 'SUB_TYPE' in params:
                filament_info['SUB_TYPE'] = str(params.pop('SUB_TYPE'))

            if 'HOTEND_MIN_TEMP' in params:
                filament_info['HOTEND_MIN_TEMP'] = int(params.pop('HOTEND_MIN_TEMP'))
            if 'HOTEND_MAX_TEMP' in params:
                filament_info['HOTEND_MAX_TEMP'] = int(params.pop('HOTEND_MAX_TEMP'))
            if 'BED_TEMP' in params:
                filament_info['BED_TEMP'] = int(params.pop('BED_TEMP'))

            if 'ALPHA' in params:
                filament_info['ALPHA'] = int(params.pop('ALPHA')) & 0xFF
            if 'RGB_1' in params:
                filament_info['RGB_1'] = int(params.pop('RGB_1')) & 0xFFFFFF
            filament_info['COLOR_NUMS'] = 1
            for key in ('RGB_2', 'RGB_3', 'RGB_4', 'RGB_5'):
                if key in params:
                    filament_info[key] = int(params.pop(key)) & 0xFFFFFF
                    filament_info['COLOR_NUMS'] += 1
            filament_info['ARGB_COLOR'] = filament_info['ALPHA'] << 24 | filament_info['RGB_1']

            if 'MULTI_MODE' in params:
                filament_info['MULTI_MODE'] = int(params.pop('MULTI_MODE')) & 0xFF
            if 'SKU' in params:
                filament_info['SKU'] = int(params.pop('SKU'))

            if params:
                raise web_request.error("unsupported fields: %s" % (', '.join(sorted(params.keys()))))

            filament_info['OFFICIAL'] = has_params
            filament_info['CARD_EVENT_TIME'] = self.reactor.monotonic()
            self._state[channel] = FILAMENT_DT_STATE_IDLE

            ptc = self.printer.lookup_object('print_task_config', None)
            if has_params or ptc is not None and ptc.print_task_config['filament_official'][channel]:
                self._filament_info_update(channel, filament_info, True)
            else:
                self._filament_info[channel] = filament_info
            web_request.send({'state': 'success'})
        except Exception as e:
            logging.error("[filament_detect] set: %s", str(e))
            web_request.set_error(web_request.error(str(e)))

    def get_all_filament_info(self):
        return self._filament_info

    def is_startup_stay(self):
        return self._config['startup_stay']

    def cmd_FILAMENT_DT_QUERY(self, gcmd):
        channel = gcmd.get_int('CHANNEL', None)

        if (channel is None):
            raise gcmd.error("CHANNEL must be specified!")

        if (channel < 0 or channel >= self._channel_nums):
            msg = ("channel[%d] is out of range[0, %d]" % (channel, self._channel_nums - 1))
            raise gcmd.error(msg)

        msg = ("channel[%d] vendor = %s, main_type: %s, sub_type= %s, rgba_color = %08X\n"
                % (channel,
                    self._filament_info[channel]['VENDOR'],
                    self._filament_info[channel]['MAIN_TYPE'],
                    self._filament_info[channel]['SUB_TYPE'],
                    self._filament_info[channel]['ARGB_COLOR']))
        gcmd.respond_info(msg, log=False)

    def cmd_FILAMENT_DT_UPDATE(self, gcmd):
        channel = gcmd.get_int('CHANNEL', None)

        if (channel is None):
            raise gcmd.error("CHANNEL must be specified!")

        if (channel < 0 or channel >= self._channel_nums):
            msg = ("channel[%d] is out of range[0, %d]" % (channel, self._channel_nums - 1))
            raise gcmd.error(msg)

        self.request_update_filament_info(channel)

    def cmd_FILAMENT_DT_CLEAR(self, gcmd):
        channel = gcmd.get_int('CHANNEL', None)

        if (channel is None):
            raise gcmd.error("CHANNEL must be specified!")

        if (channel < 0 or channel >= self._channel_nums):
            msg = ("channel[%d] is out of range[0, %d]" % (channel, self._channel_nums - 1))
            raise gcmd.error(msg)

        self.request_clear_filament_info(channel)

    def cmd_FILAMENT_DT_SELF_TEST(self, gcmd):
        channel = gcmd.get_int('CHANNEL', None)
        times = gcmd.get_int('TIMES', 100)

        if not self._fm175xx_reader:
            raise gcmd.error("Built-in RFID reader disabled")

        if (channel is None):
            raise gcmd.error("CHANNEL must be specified!")

        if (channel < 0 or channel >= self._channel_nums):
            msg = ("channel[%d] is out of range[0, %d]" % (channel, self._channel_nums - 1))
            raise gcmd.error(msg)

        self._state[channel] = FILAMENT_DT_STATE_SELF_TESTING
        finish = False
        test_times = 0
        success_times = 0
        self._self_test_success_cnt = 0
        self._fm175xx_reader.self_test(channel, times)
        while (1):
            finish, test_times, success_times = self._fm175xx_reader.self_test_result()
            if finish:
                break
            self.reactor.pause(self.reactor.monotonic() + 0.3)

        msg = ("channel[%d] test times = %d, success times: %d\n" % (
                channel, test_times, self._self_test_success_cnt))
        gcmd.respond_info(msg, log=False)
        msg = ("channel[%d] vendor = %s, main_type: %s, sub_type= %s, argb_color = %08X\n"
                % (channel,
                    self._filament_info[channel]['VENDOR'],
                    self._filament_info[channel]['MAIN_TYPE'],
                    self._filament_info[channel]['SUB_TYPE'],
                    self._filament_info[channel]['ARGB_COLOR']))
        gcmd.respond_info(msg, log=False)
        self._state[channel] = FILAMENT_DT_STATE_IDLE

    def cmd_FILAMENT_DT_STARTUP_STAY(self, gcmd):
        stay = gcmd.get_int('STAY', None)
        need_save = gcmd.get_int('SAVE', 1, minval=0, maxval=1)
        if (stay is None):
            raise gcmd.error("STAY must be specified!")

        self._config['startup_stay']= bool(stay)

        if (need_save):
            load_config = self.printer.load_snapmaker_config_file(self._config_path, DEFAULT_FILAMENT_DT_CONFIG)
            load_config['startup_stay'] = bool(stay)
            ret = self.printer.update_snapmaker_config_file(self._config_path, load_config, DEFAULT_FILAMENT_DT_CONFIG)
            if not ret:
                raise gcmd.error("save startup stay failed!")

    def get_status(self, eventtime=None):
        return {
            'info': [dict(info) for info in self._filament_info],
            'state': list(self._state),
            'config': dict(self._config)}

    def factory_reset(self):
        self._config = dict(DEFAULT_FILAMENT_DT_CONFIG)
        ret = self.printer.update_snapmaker_config_file(self._config_path, self._config, DEFAULT_FILAMENT_DT_CONFIG)
        if not ret:
            logging.error("save filament_detect config failed!")
        return ret

def load_config(config):
    return FilamentDetector(config)

